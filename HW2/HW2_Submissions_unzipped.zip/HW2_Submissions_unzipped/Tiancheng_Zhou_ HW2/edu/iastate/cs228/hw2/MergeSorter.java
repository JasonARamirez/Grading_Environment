package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 

/**
 *  
 * @Tiancheng Zhou
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	// Other private instance variables if you need ... 
	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/** 
	 * Constructor accepts an input array of points. 
	 * in the array. 
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		super(pts);
		this.algorithm="merge sort";
		this.outputFileName="merge.txt";
	}
	
	
	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public MergeSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		super(inputFileName);
		this.algorithm="merge sort";
		this.outputFileName="merge.txt";
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{
		setComparator(order);
		long startTime= System.nanoTime();
		mergeSortRec(points);
		sortingTime=System.nanoTime()-startTime;
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts) {
		if (pts.length > 1) 
		{ 
			int midpoint = pts.length / 2;
			Point[] left = new Point[pts.length / 2];
			Point[] right = new Point[pts.length - left.length];
			System.arraycopy(pts, 0, left, 0, left.length);
			System.arraycopy(pts, left.length, right, 0, right.length);
			mergeSortRec(left);
			mergeSortRec(right);
			//merge
			int i = 0;
			int j = 0;
			int k = 0;
			while (i < left.length && j < right.length) 
			{
				if (pointComparator.compare(left[i], right[j]) < 0) 
				{
					pts[k+=1] = left[i+=1];
				} 
				else
					pts[k+=1] = right[j+=1];
			}
			while (i < left.length) 
			{
				pts[k+=1] = left[i+=1];
			}

			while (j < right.length)
			{
				pts[k+=1] = right[j+=1];
			}

		}
	}

}


	
	// Other private methods in case you need ...


