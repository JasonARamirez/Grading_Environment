package edu.iastate.cs228.hw2;

import java.util.Comparator;

/**
 * 
 * This class compares two points p1 and p2 by polar angle with respect to a reference point.  
 * It is known that the reference point is not above either p1 or p2, and in the case that
 * either or both of p1 and p2 have the same y-coordinate as referencePoint, not to their right. 
 *
 * @author Ross Thedens
 *
 */
public class PolarAngleComparator implements Comparator<Point>
{
	private Point referencePoint;	// The reference point that all polar angles are measured with respect to.
	
	/**
	 * Constructs a new PolarAngleComparator using the given reference point. This class does not modify the reference point
	 * 
	 * @param p reference point
	 */
	public PolarAngleComparator(Point p)
	{
		referencePoint = p; 
	}
	
	/**
	 * This method compares two points based on their polar angle with respect to referencePoint.
	 * 
	 * Use cross product and dot product to implement this method. These are called in comparePolarAngle and compareDistance, which are called by this method.
	 * 
	 * See the return description below for an accurate description of this method's behavior. This is based upon the slides in assn2_basic_geometry.pptx.
	 * The old, messy javadoc description has been replaced with an accurate, neat one
	 * 
	 * @param p1
	 * 	One of the points to compare
	 * @param p2
	 * 	The other point to compare
	 * @return  0 if p1 and p2 have the same polar angle w.r.t. referencePoint and an equal distance from referencePoint (they are the same point)
	 *         -1 if p1 has a smaller polar angle w.r.t. referencePoint or p1 and p2 are collinear (same polar angle) and p1 is closer to referencePoint than p2
	 *          1 if p1 has a larger polar angle w.r.t. referencePoint or p1 and p2 are collinear (same polar angle) and p1 is further from referencePoint than p2 
	 *                   
	 */
	public int compare(Point p1, Point p2)
	{		
		if(comparePolarAngle(p1, p2) == 0)
			return compareDistance(p1, p2);
		
		return comparePolarAngle(p1, p2);
	}
	
	
	/**
	 * Compares the polar angles of two points p1 and p2 with respect to referencePoint using cross products.
	 * 
	 * Ought to be private but made public for testing purpose. 
	 * 
	 * See the return description below for an accurate description of this method's behavior.
	 * 
	 * @param p1
	 * 	One of the points to compare
	 * @param p2
	 * 	The other point to compare
	 * @return    0  if p1 and p2 have the same polar angle with respect to referencePoint (they are collinear, cross product is zero)
	 * 			 -1  if p1 has a smaller polar angle w.r.t. referencePoint than p2 (cross product is positive)
	 *            1  otherwise (cross product is negative, p1 has a greater polar angle w.r.t. referencePoint)
	 */
    public int comparePolarAngle(Point p1, Point p2)
    {
		if(crossProduct(p1, p2) == 0)
			return 0;
    	
    		if(crossProduct(p1, p2) > 0)
			return -1;
    		
    		return 1;
    		
    }
    
    
    /**
     * Compare the distances of two points p1 and p2 to referencePoint using dot products.
     * 
     * Ought to be private but made public for testing purpose.
     * 
     * See the return description below for an accurate description of this method's behavior.
     * 
     * @param p1
     * 	One point to compare
     * @param p2
     * 	The other point to compare
     * @return    0   if p1 and p2 are equidistant to referencePoint
     * 			 -1   if p1 is closer to referencePoint 
     *            1   otherwise (i.e., if p2 is closer to referencePoint)
     */
    public int compareDistance(Point p1, Point p2)
    {
    
    		if(dotProduct(p1, p1) == dotProduct(p2, p2))
    			return 0;
    	
    		if(dotProduct(p1, p1) < dotProduct(p2, p2))
    			return -1;
    		
    		return 1; 
    }
    

    /**
     * Computes the cross product of the vectors from referencePoint to the points p1 and p2.
     *
     * @param p1
     * 	One point to use for a cross product vector
     * @param p2
     * 	The other point to use for a cross product vector
     * @return cross product of two vectors p1 - referencePoint and p2 - referencePoint
     */
    private int crossProduct(Point p1, Point p2)
    { 
		int p1XComp = p1.getX() - referencePoint.getX();
		int p1YComp = p1.getY() - referencePoint.getY();
		int p2XComp = p2.getX() - referencePoint.getX();
		int p2YComp = p2.getY() - referencePoint.getY();
    		return p1XComp * p2YComp - p2XComp * p1YComp; 
    }

    /**
     * Computes the dot product of the vectors from referencePoint to the points p1 and p2.
     * 
     * @param p1
     * 	One point to use for a dot product vector
     * @param p2
     * 	The other point to use for a dot product vector
     * @return dot product of two vectors p1 - referencePoint and p2 - referencePoint
     */
    private int dotProduct(Point p1, Point p2)
    {
    		int p1XComp = p1.getX() - referencePoint.getX();
    		int p1YComp = p1.getY() - referencePoint.getY();
    		int p2XComp = p2.getX() - referencePoint.getX();
    		int p2YComp = p2.getY() - referencePoint.getY();
    		return p1XComp * p2XComp + p1YComp * p2YComp; 
    }
    
}  
