package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 


/**
 * 
 * This class extends AbstractSorter to implement a mergesort algorithm.
 * 
 * @author Ross Thedens
 *
 */

public class MergeSorter extends AbstractSorter
{	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/** 
	 * This constructor accepts an input array of points. 
	 * in the array. 
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		super(pts);
		setMergeSorterFields();
	}
	
	
	/**
	 * This constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 	if the file cannot be read
	 * @throws InputMismatchException 	if the file contains an odd number of ints or zero ints
	 */
	public MergeSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		super(inputFileName);
		setMergeSorterFields();
	}


	/**
	 * Performs a mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{
		if(order == 1)
			sortByAngle = false;
		
		else if(order == 2)
			sortByAngle = true;
			
		else
			throw new IllegalArgumentException();
		
		setComparator();
		long startTime = System.nanoTime();
		mergeSortRec(points);
		sortingTime = System.nanoTime() - startTime;
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array to sort
	 */
	private void mergeSortRec(Point[] pts)
	{
		if(pts.length > 1)
		{
			int firsthalflength = pts.length / 2;
			Point[] firsthalf = new Point[firsthalflength];
			System.arraycopy(pts, 0, firsthalf, 0, firsthalflength);
			mergeSortRec(firsthalf);
			
			int secondhalflength = pts.length - pts.length / 2;
			Point[] secondhalf = new Point[secondhalflength];
			System.arraycopy(pts, firsthalflength, secondhalf, 0, secondhalflength);
			mergeSortRec(secondhalf);
			
			merge(firsthalf, secondhalf, pts);
		}
	}

	/**
	 * Merges two sorted arrays into a sorted full array
	 * @param firsthalf
	 * 	One array to merge
	 * @param secondhalf
	 * 	The other array to merge
	 * @param whole
	 * 	The destination array
	 */
	private void merge(Point[] firsthalf, Point[] secondhalf, Point[] whole)
	{
		int firsthalfindex = 0;
		int secondhalfindex = 0;
		int wholeindex = 0;
		
		while(firsthalfindex < firsthalf.length && secondhalfindex < secondhalf.length)
		{
			if(pointComparator.compare(firsthalf[firsthalfindex], secondhalf[secondhalfindex]) < 0)
			{
				whole[wholeindex] = firsthalf[firsthalfindex];
				firsthalfindex++;
				wholeindex++;
			}
			
			else
			{
				whole[wholeindex] = secondhalf[secondhalfindex];
				secondhalfindex++;
				wholeindex++;
			}
		}
		
		while(firsthalfindex < firsthalf.length)
		{
			whole[wholeindex] = firsthalf[firsthalfindex];
			firsthalfindex++;
			wholeindex++;
		}
		
		while(secondhalfindex < secondhalf.length)
		{
			whole[wholeindex] = secondhalf[secondhalfindex];
			secondhalfindex++;
			wholeindex++;
		}
	}


	/**
	 * Sets fields unique to this sorter (algorithm and outputFileName)
	 */
	private void setMergeSorterFields()
	{
		algorithm = "merge sort";
		outputFileName = "merge.txt";
	}
	
}
