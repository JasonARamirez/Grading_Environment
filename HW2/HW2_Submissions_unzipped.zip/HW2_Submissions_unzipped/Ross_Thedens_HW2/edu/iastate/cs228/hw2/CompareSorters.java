package edu.iastate.cs228.hw2;

/**
 * 
 * This class executes four sorting algorithms: selection sort, insertion sort, mergesort, and
 * quicksort, over randomly generated integers as well integers from a file input. It compares the 
 * execution times of these algorithms on the same input. 
 *
 * @author Ross Thedens
 *
 */

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.Random; 


public class CompareSorters 
{
	/**
	 * Repeatedly take integer sequences either randomly generated or read from files. 
	 * Perform the four sorting algorithms over each sequence of integers, comparing 
	 * points by x-coordinate or by polar angle with respect to the lowest point.  
	 * 
	 * Note that any int besides 1 or 2 will count as an exit key.
	 * 
	 * Important Note: It is assumed that the user will enter correct ints and filenames in all other situations.
	 * Exceptions are not caught in this method.
	 * 
	 * @param args
	 * 	Command line arguments for main
	 * @throws FileNotFoundException 	if file cannot be read
	 * @throws InputMismatchException 	if file contains an odd number of ints
	 **/
	
	public static void main(String[] args) throws InputMismatchException, FileNotFoundException 
	{		
		// Conducts multiple sorting rounds. In each round, performs the following: 
		// 
		//    1) Asks for a key to determine whether random integers will be sorted, points from a file will be sorted, or the main will terminate
		//    2) Asks for a number of random points to generate if random generation were selected, or asks for a filename if points from a file was selected. 
		//    3) Based on the input point order, carries out the four sorting algorithms in a for 
		//       loop that iterates over the array sorters[], to sort the randomly generated points
		//       or points from an input file.  
		//    4) Meanwhile, prints out the table of runtime statistics. Also saves the results of each sort to their corresponding output files.
		// 
		// A sample scenario is given in Section 2 of the assignment description. 
		// 	
		
		
		AbstractSorter[] sorters = new AbstractSorter[4];
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Comparison of Four Sorting Algorithms\n");
		System.out.println("keys: 1 (random integers) 2 (file input) 3 (exit)");
		System.out.println("order: 1 (by x-coordinate) 2 (by polar angle)\n");
		
		int trial = 1;
		
		while(true)
		{
			System.out.print("Trial " + trial + " => Enter key: ");
			int key = s.nextInt();
			
			if(key == 1)
			{
				System.out.print("Enter number of random points: ");
				int numPts = s.nextInt();
				Random rand = new Random();
				Point[] pts = generateRandomPoints(numPts, rand);
				sorters[0] = new SelectionSorter(pts);
				sorters[1] = new InsertionSorter(pts);
				sorters[2] = new MergeSorter(pts);
				sorters[3] = new QuickSorter(pts);
			}
			
			else if(key == 2)
			{
				System.out.println("Points from a file");
				System.out.print("File name: ");
				String filename = s.next();
				sorters[0] = new SelectionSorter(filename);
				sorters[1] = new InsertionSorter(filename);
				sorters[2] = new MergeSorter(filename);
				sorters[3] = new QuickSorter(filename);
			}
			
			else
			{
				break;
			}
						
			System.out.print("Order used in sorting: ");
			int order = s.nextInt();
			
			System.out.println("\n");
			
			String dashedLine = "---------------------------------------------";
			System.out.println(String.format("%-20s%-12s%s", "algorithm", "size", "time (ns)"));
			System.out.println(dashedLine + "\n");
			
			for(int i = 0; i < sorters.length; i++)
			{
				// Within a sorting round, every sorter object write its output to the file 
				// "select.txt", "insert.txt", "merge.txt", or "quick.txt" if it is an object of 
				// SelectionSort, InsertionSort, MergeSort, or QuickSort, respectively. 
				
				sorters[i].sort(order);
				System.out.println(sorters[i].stats());
				sorters[i].writePointsToFile();
			}
						
			System.out.println(dashedLine + "\n");
			trial++;
		}
		s.close();
	}
	
	
	/**
	 * This method generates a given number of random points to initialize randomPoints[].
	 * The coordinates of these points are pseudo-random numbers within the range 
	 * [-50,50] � [-50,50]. Please refer to Section 3 of assignment description document on how such points can be generated.
	 * 
	 * Ought to be private. Made public for testing. 
	 * 
	 * @param numPts  	number of points
	 * @param rand      Random object to generate the coordinates
	 * @throws IllegalArgumentException if numPts < 1
	 * @return The array of random points with x and y coordinates [-50, 50].
	 */
	public static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException
	{ 
		if(numPts < 1)
			throw new IllegalArgumentException();
		
		Point[] randPts = new Point[numPts];
		
		for(int i = 0; i < numPts; i++)
		{
			int randXCoord = rand.nextInt(101) - 50;
			int randYCoord = rand.nextInt(101) - 50;
			randPts[i] = new Point(randXCoord, randYCoord);
		}
		
		return randPts; 
	}
}
