package edu.iastate.cs228.hw2;

/**
 * 
 * This abstract class is extended by SelectionSort, InsertionSort, MergeSort, and QuickSort.
 * It stores the input (later on the sorted) sequence and records the employed sorting algorithm, 
 * the comparison method, and the time spent on sorting.
 * 
 * @author Ross Thedens
 *
 */

import java.util.Comparator;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;
import java.util.Scanner;

public abstract class AbstractSorter
{
	
	protected Point[] points;    // Array of points operated on by a sorting algorithm. 
	                             // The number of points is given by points.length.
	
	protected String algorithm = null; // "selection sort", "insertion sort",  
	                                   // "merge sort", or "quick sort". Initialized by a subclass 
									   // constructor, indicates the algorithm used.
	protected boolean sortByAngle;     // true if last sort was done by polar angle and false 
									   // if by x-coordinate 
	
	protected String outputFileName;   // Name of the output file: "select.txt", "insert.txt", "merge.txt", or "quick.txt"
	
	protected long sortingTime; 	   // execution time of the algorithm in nanoseconds. 
	 
	protected Comparator<Point> pointComparator;  // comparator which compares polar angle if 
												  // sortByAngle == true and x-coordinate if 
												  // sortByAngle == false 
	
	private Point lowestPoint; 	    // lowest point in the array, or in case of a tie, the
									// leftmost of the lowest points. This point is used 
									// as the reference point for polar angle based comparison.	
	
	/**
	 * This constructor accepts an array of points as input. Copies the points into the array points[]. 
	 * Sets the instance variable lowestPoint.
	 * 
	 * @param  pts  input array of points 
	 * @throws IllegalArgumentException if pts == null or pts.length == 0.
	 */
	protected AbstractSorter(Point[] pts) throws IllegalArgumentException
	{
		if(pts == null || pts.length == 0)
			throw new IllegalArgumentException();
		
		copyPointsAndSetLowestPoint(pts);
	}

	
	/**
	 * This constructor reads points from a file. Sets the instance variables lowestPoint and 
	 * outputFileName.
	 * 
	 * Note that the file must come from the project's main directory, NOT the src folder.
	 * 
	 * @param  inputFileName
	 * 	The name of the file containing the points.
	 * @throws FileNotFoundException 	when the filename supplied does not correspond with an actual file
	 * @throws InputMismatchException   when the input file contains an odd number of integers
	 */
	protected AbstractSorter(String inputFileName) throws FileNotFoundException, InputMismatchException
	{		
		// Do an initial pass to count the number of ints so a) we know the size of our array and b) we know whether to throw an InputMismatchException
		File f = new File(inputFileName);
		Scanner scCount = new Scanner(f);
		int intCount = countIntsInScanner(scCount);
		scCount.close();
		
		// Throw the exception if necessary
		if(intCount % 2 != 0 || intCount == 0)
			throw new InputMismatchException();
		
		// Read all ints from the file
		int[] coords = new int[intCount];
		int coordIndex = 0;
		Scanner scRead = new Scanner(f);
		while(scRead.hasNextInt())
		{
			coords[coordIndex] = scRead.nextInt();
			coordIndex++;
		}
		scRead.close();
		
		// Create an array of points from the array of ints
		// Even length allows this to work.
		Point[] pts = new Point[coords.length / 2];
		for(int i = 0, j = 0; i < coords.length; i+=2, j++)
		{
			pts[j] = new Point(coords[i], coords[i+1]);
		}
		
		// Copy the array to the points field and set the lowest point
		copyPointsAndSetLowestPoint(pts);
	}
	

	/**
	 * Sorts the elements in points[]. 
	 * 
	 *     a) in the non-decreasing order of x-coordinate if order == 1
	 *     b) in the non-decreasing order of polar angle w.r.t. lowestPoint if order == 2 
	 *        (lowestPoint will be at index 0 after sorting)
	 * 
	 * Sets the instance variable sortByAngle based on the value of order. Calls the method 
	 * setComparator() to set the variable pointComparator and use it in sorting.    
	 * Records the sorting time (in nanoseconds) using the System.nanoTime() method. 
	 * (Assign the time to the variable sortingTime.)  
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle w.r.t lowestPoint 
	 *
	 * @throws IllegalArgumentException if order is less than 1 or greater than 2
	 * 	This is thrown in the subclass implementations of this, but the exception is not explicitly declared.
	 */
	public abstract void sort(int order) throws IllegalArgumentException; 
	
	/**
	 * Outputs performance statistics in the format: 
	 * 
	 * <sorting algorithm> <size>  <time>
	 * 
	 * For instance, 
	 * 
	 * selection sort   1000	  9200867
	 * 
	 * Uses the spacing in the sample run in Section 2 of the assignment description. 
	 */
	public String stats()
	{
		return String.format("%-20s%-12s%s", algorithm, points.length, sortingTime); 
		
	}
	
	
	/**
	 * Writes points[] to a string.  When printed, the points will appear in order of increasing
	 * index with every point occupying a separate line.  The x and y coordinates of the point are 
	 * displayed on the same line with exactly one blank space in between.
	 * 
	 * Note that the last ordered pair is followed by a newline.
	 *  
	 *  @return
	 *  	The points as a string
	 */
	@Override
	public String toString()
	{
		String s = "";
		
		int i;
		for(i = 0; i < points.length; i++)
		{
			s += points[i].getX() + " " + points[i].getY() + "\n";
		}
				
		return s; 
	}

	
	/**
	 *  
	 * This method, called after sorting, writes point data into a file by outputFileName. It will 
	 * be used for Mathematica plotting to verify the sorting result.  The data format depends on 
	 * sortByAngle.  It is detailed in Section 4.1 of the assignment description assn2.pdf. 
	 * 
	 * Note that the i-th contains points[i]'s coordinates, and i runs from 1 to points.length - 1 (inclusive)
	 * 
	 * A newline character is printed at the end of the last line, but this has no impact on the readability of the file
	 * 
	 * Note that the file will be saved to the project's main directory, NOT the src folder.
	 * 
	 * @throws FileNotFoundException if a file cannot be created
	 */
	public void writePointsToFile() throws FileNotFoundException
	{
		File f = new File(outputFileName);
		PrintWriter pw = new PrintWriter(f);
		
		if(!sortByAngle)
		{
			pw.write(this.toString());
		}
		else
		{
			int i;
			String leastPointString = points[0].getX() + " " + points[0].getY();
			pw.write(leastPointString + "\n");
			for(i = 1; i < points.length; i++)
			{
				String leftHandSide = points[i].getX() + " " + points[i].getY() + " ";
				String rightHandSide = " " + points[i].getX() + " " + points[i].getY();
				pw.write(leftHandSide + leastPointString + rightHandSide + "\n");
			}
			
		}
		pw.close();
	}	

	
	/**
	 * Generates a comparator on the fly that compares by polar angle if sortByAngle == true
	 * and by x-coordinate if sortByAngle == false. Set the protected variable pointComparator
	 * to it. Need to create an object of the PolarAngleComparator class and call the compareTo() 
	 * method in the Point class, respectively for the two possible values of sortByAngle.  
	 * 
	 * Note: This method reflects the instructor post "Assignment 2 typo in AbstractSorter class template" from Monday, October 2, 2017 2:23:00 PM CDT:
	 * 
	 * "... This method, i.e., setComparator, does not need a parameter, i.e., it needs to be "protected void setComparator()...'"
	 */
	protected void setComparator() 
	{
		if(sortByAngle)
		{
			pointComparator = new PolarAngleComparator(lowestPoint);
		}
		else
		{	
			pointComparator = new Comparator<Point>()
			{
				@Override
				public int compare(Point p1, Point p2)
				{
					return p1.compareTo(p2);
				}
			};
		}
		
		
	}

	
	/**
	 * Swap the two elements indexed at i and j respectively in the array points[]. 
	 * 
	 * @param i
	 * 	Index of one of the elements
	 * @param j
	 * 	Index of the other element
	 */
	protected void swap(int i, int j)
	{
		Point temp = points[i];
		points[i] = points[j];
		points[j] = temp;
	}
	
	/**
	 * Uses a given Scanner that is already reading from an input source to determine the number of ints in that source.
	 * This does not open or close any Scanners.
	 * @param sc
	 * 	The Scanner reading the source
	 * @return
	 * 	The number of ints found
	 */
	private int countIntsInScanner(Scanner sc)
	{
		int countInts = 0;
		
		while(sc.hasNextInt())
		{
			sc.nextInt();
			countInts++;
		}
		return countInts;
	}
	
	/**
	 * This method deep copies the array of points given into the points field of AbstractSorter.
	 * Concurrently, it determines the lowest point and deep copies that point into the lowestPoint field of AbstractSorter.
	 * @param pts
	 * 	The array of points to be copied in
	 */
	private void copyPointsAndSetLowestPoint(Point[] pts)
	{
		points = new Point[pts.length];
		Point lowpt = pts[0];
		for(int i = 0; i < pts.length; i++)
		{
			if(pts[i].getY() < lowpt.getY() || pts[i].getY() == lowpt.getY() && pts[i].getX() < lowpt.getX())
				lowpt = pts[i];
				
			points[i] = new Point(pts[i]);
		}
		
		lowestPoint = new Point(lowpt);
	}
}
