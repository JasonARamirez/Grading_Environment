package edu.iastate.cs228.hw2;

/**
 * A class representing a point in a Cartesian plane
 * 
 * @author Ross Thedens
 *
 */

public class Point implements Comparable<Point>
{
	private int x;	// The x coordinate
	private int y;	// The y coordinate
	
	/**
	 * Constructs a point with the default x and y values of zero.
	 */
	public Point() // default constructor
	{
		// x and y get default value 0
	}
	
	/**
	 * Constructs a Point with the given x and y coordinates
	 * @param x
	 * 	The x coordinate to use
	 * @param y
	 * 	The y coordinate to use
	 */
	public Point(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
	
	/**
	 * Copy constructor to copy an existing point
	 * @param p
	 * 	The existing point to copy
	 */
	public Point(Point p)
	{ // copy constructor
		x = p.getX();
		y = p.getY();
	}
	
	/**
	 * Gets the value of x
	 * @return
	 * 	the value of x
	 */
	public int getX()
	{
		return x;
	}
	
	/**
	 * Gets the value of y
	 * @return
	 * 	the value of y
	 */
	public int getY()
	{
		return y;
	}
	
	/**
	 * An implementation of the equals method for Points
	 *
	 * @param obj
	 * 	The other Object (Point) to compare to this point
	 * 
	 * @return
	 * 	true if the two points are equal, false otherwise.
	 */
	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || obj.getClass() != this.getClass())
		{
			return false;
		}
		
		Point other = (Point) obj;
		return x == other.x && y == other.y;
	}
	
	/**
	 * Compare this point with a second point q in the left-to-right order.
	 * 
	 * @param q
	 * 	The point to compare to this one
	 * @return -1 if this.x < q.x || (this.x == q.x && this.y < q.y)
	 *  0 if this.x == q.x && this.y == q.y
	 *  1 otherwise
	 */
	public int compareTo(Point q)
	{
		if (this.x < q.x || (this.x == q.x && this.y < q.y))
			return -1;
		
		if (this.x == q.x && this.y == q.y)
			return 0;
		
		return 1;
	}
	
	/**
	 * Output a point in the standard form (x, y).
	 * 
	 * @return
	 * 	The Point's standard form String
	 */
	@Override
	public String toString()
	{
		return "(" + this.x + ", " + this.y + ")";
	}
}
