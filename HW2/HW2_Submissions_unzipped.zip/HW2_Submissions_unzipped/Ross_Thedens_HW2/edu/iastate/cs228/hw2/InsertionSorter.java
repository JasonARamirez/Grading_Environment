package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException;


/**
 * 
 * This class extends AbstractSorter to implement an insertion sort algorithm.
 *
 * @author Ross Thedens
 *
 */

public class InsertionSorter extends AbstractSorter
{
	
	/**
	 * The two constructors below invoke their corresponding superclass
	 * constructors. They also set the instance variables algorithm and
	 * outputFileName in the superclass.
	 */
	
	/**
	 * This constructor takes an array of points.
	 * 
	 * @param pts
	 * 	The input array of points
	 */
	public InsertionSorter(Point[] pts)
	{
		super(pts);
		setInsertionSorterFields();
	}
	
	/**
	 * This constructor reads points from a file.
	 * 
	 * @param inputFileName
	 *            name of the input file
	 * @throws FileNotFoundException 	if the file cannot be read
	 * @throws InputMismatchException 	if the file contains an odd number of ints or zero ints
	 */
	public InsertionSorter(String inputFileName) throws InputMismatchException, FileNotFoundException
	{
		super(inputFileName);
		setInsertionSorterFields();
	}
	
	/**
	 * Perform an insertion sort on the array points[] of the parent class
	 * AbstractSorter.
	 * 
	 * @param order
	 *            1 by x-coordinate 2 by polar angle
	 */
	@Override
	public void sort(int order)
	{
		if(order == 1)
			sortByAngle = false;
		
		else if(order == 2)
			sortByAngle = true;
			
		else
			throw new IllegalArgumentException();
		
		setComparator();
		
		long startTime = System.nanoTime();
		
		for(int i = 0; i < points.length; i++)
		{
			Point p = points[i];
			int j;
			for(j = i - 1; j >= 0 && pointComparator.compare(points[j], p) > 0; j--)
			{
				points[j + 1] = points[j];
			}
			points[j + 1] = p;
		}
		
		sortingTime = System.nanoTime() - startTime;

	}
	
	/**
	 * Sets fields unique to this sorter (algorithm and outputFileName)
	 */
	private void setInsertionSorterFields()
	{
		algorithm = "insertion sort";
		outputFileName = "insert.txt";
	}
}
