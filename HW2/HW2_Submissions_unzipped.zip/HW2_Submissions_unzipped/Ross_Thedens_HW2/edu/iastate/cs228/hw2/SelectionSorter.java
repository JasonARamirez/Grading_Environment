package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 


/**
 *  This class extends AbstractSorter to implement a selection sort algorithm.
 *  
 * @author Ross Thedens
 *
 */

public class SelectionSorter extends AbstractSorter
{	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/**
	 * This constructor that takes an array of points.
	 *  
	 * @param pts
	 * 	The points array to construct the sorter from 
	 */
	public SelectionSorter(Point[] pts)  
	{
		super(pts);
		setSelectionSorterFields();
	}	
	
	/**
	 * This constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 	if the file cannot be read
	 * @throws InputMismatchException 	if the file contains an odd number of ints or zero ints
	 */
	public SelectionSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		super(inputFileName);
		setSelectionSorterFields();
	}
	
	
	/** 
	 * Applies a selection sort to the array points[] of the parent class AbstractSorter.  
	 *
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{
		if(order == 1)
			sortByAngle = false;
		
		else if(order == 2)
			sortByAngle = true;
			
		else
			throw new IllegalArgumentException();
		
		setComparator();
		
		long startTime = System.nanoTime();
		
		for(int i = 0; i < points.length; i++)
		{
			int minIndex = i;
			for(int j = i + 1; j < points.length; j++)
			{
				if(pointComparator.compare(points[j], points[minIndex]) < 0)
					minIndex = j;
			}
			swap(i, minIndex);
		}
		
		sortingTime = System.nanoTime() - startTime;
	}
	
	/**
	 * Sets the unique fields for this Sorter (algorithm and outputFileName)
	 */
	private void setSelectionSorterFields()
	{
		algorithm = "selection sort";
		outputFileName = "select.txt";
	}
}
