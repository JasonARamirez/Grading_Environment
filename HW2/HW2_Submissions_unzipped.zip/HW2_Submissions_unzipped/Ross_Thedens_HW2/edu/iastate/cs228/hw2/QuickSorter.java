package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 

/**
 * 
 * This class extends AbstractSorter to implement the version of the quicksort algorithm presented in the lecture.
 * 
 *  @author Ross Thedens
 *
 */

public class QuickSorter extends AbstractSorter
{			
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/** 
	 * This constructor accepts an input array of points. 
	 *   
	 * @param pts   input array of integers
	 */
	public QuickSorter(Point[] pts)
	{
		super(pts);
		setQuickSorterFields();
	}
		

	/**
	 * This constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 	if the file cannot be read
	 * @throws InputMismatchException 	if the file contains an odd number of ints or zero ints
	 */
	public QuickSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		super(inputFileName);
		setQuickSorterFields();
	}


	/**
	 * Carries out a quicksort on the array points[] of the AbstractSorter class.  
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{
		if(order == 1)
			sortByAngle = false;
		
		else if(order == 2)
			sortByAngle = true;
			
		else
			throw new IllegalArgumentException();
		
		setComparator();
		long startTime = System.nanoTime();
		quickSortRec(0, points.length - 1);
		sortingTime = System.nanoTime() - startTime;
	}
	
	
	/**
	 * Operates on the subarray of points[] with indices between first and last.
	 * Performs a recursive quicksort.
	 * 
	 * @param first  starting index of the subarray
	 * @param last   ending index of the subarray
	 */
	private void quickSortRec(int first, int last)
	{
		if(first < last)
		{
			int mid = partition(first, last);
			quickSortRec(first, mid);
			quickSortRec(mid + 1, last);
		}
	}
	
	
	/**
	 * Operates on the subarray of points[] with indices between first and last.
	 * Partitions the array, returning the index dividing the partitions
	 * 
	 * @param first
	 * 	The beginning of the section to partition
	 * @param last
	 * 	The end of the section to partition
	 * @return
	 * 	the index dividing the partitions
	 * 	
	 */
	private int partition(int first, int last)
	{
		int low = first - 1;
		int high = last + 1;
		Point pivot = points[first];
		
		while(true)
		{
			do
			{
				low++;
			} while(pointComparator.compare(points[low], pivot) < 0);
			
			do
			{
				high--;
			} while(pointComparator.compare(points[high], pivot) > 0);
			
			if(low < high)
			{
				swap(low, high);
			}
			else
			{
				return high;
			}
		}	
	}		
	
	/**
	 * Sets fields unique to this sorter (algorithm and outputFileName)
	 */
	private void setQuickSorterFields()
	{
		algorithm = "quick sort";
		outputFileName = "quick.txt";
	}
	
}
