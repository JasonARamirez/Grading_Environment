package edu.iastate.cs228.hw2;

import java.io.File;

/**
 *  
 * @author Justin Thomas
 *
 */

/**
 * 
 * This class executes four sorting algorithms: selection sort, insertion sort, mergesort, and
 * quicksort, over randomly generated integers as well integers from a file input. It compares the 
 * execution times of these algorithms on the same input. 
 *
 */

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.Random; 


public class CompareSorters 
{
	/**
	 * Repeatedly take integer sequences either randomly generated or read from files. 
	 * Perform the four sorting algorithms over each sequence of integers, comparing 
	 * points by x-coordinate or by polar angle with respect to the lowest point.  
	 * 
	 * @param args
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 **/
	public static void main(String[] args) throws InputMismatchException, FileNotFoundException 
	{		
		// TODO 
		// 
		// Conducts multiple sorting rounds. In each round, performs the following: 
		// 
		//    a) If asked to sort random points, calls generateRandomPoints() to initialize an array 
		//       of random points. 
		//    b) Reassigns to elements in the array sorters[] (declared below) the references to the 
		//       four newly created objects of SelectionSort, InsertionSort, MergeSort and QuickSort. 
		//    c) Based on the input point order, carries out the four sorting algorithms in a for 
		//       loop that iterates over the array sorters[], to sort the randomly generated points
		//       or points from an input file.  
		//    d) Meanwhile, prints out the table of runtime statistics.
		// 
		// A sample scenario is given in Section 2 of the assignment description. 
		// 	
		Random test =new Random();
		AbstractSorter[] sorters = new AbstractSorter[4]; 
		Point[] testcase = generateRandomPoints(20,test);
		sorters[0]= new MergeSorter("points.txt");        //NOTE: PLACE TARGET FILE IN PARENT DIRECTORY (NEXT TO THE "src" DIRECTORY)
		sorters[1]= new SelectionSorter("points.txt");
		sorters[2]= new InsertionSorter("points.txt");
		sorters[0].sort(1);
		sorters[1].sort(1);
		sorters[2].sort(1);
		sorters[0].writePointsToFile();
		sorters[1].writePointsToFile();
		sorters[2].writePointsToFile();
		
		System.out.println("Method  \tSize \tTime(ns)\n"+
				"--------------------------------------");
		for(int i=0;i<3;++i) {
			System.out.println(sorters[i].stats());
		}
		sorters[0]= new MergeSorter(testcase);
		sorters[1]= new SelectionSorter(testcase);
		sorters[2]= new InsertionSorter(testcase);
		sorters[0].sort(1);
		sorters[1].sort(1);
		sorters[2].sort(1);
		sorters[0].writePointsToFile();
		sorters[1].writePointsToFile();
		sorters[2].writePointsToFile();
		
		System.out.println("Method  \tSize \tTime(ns)\n"+
				"--------------------------------------");
		for(int i=0;i<3;++i) {
			System.out.println(sorters[i].stats());
		}
		System.out.println("\n HI, just as a heads up, everything but Quick sort is implemented correctly. I diddnt get to quick\n"
				+ "because It was really confusing to make in this case, I hope you understand");
		
		
		
		// Within a sorting round, every sorter object write its output to the file 
		// "select.txt", "insert.txt", "merge.txt", or "quick.txt" if it is an object of 
		// SelectionSort, InsertionSort, MergeSort, or QuickSort, respectively. 
		
	}
	
	
	/**
	 * This method generates a given number of random points to initialize randomPoints[].
	 * The coordinates of these points are pseudo-random numbers within the range 
	 * [-50,50] � [-50,50]. Please refer to Section 3 of assignment description document on how such points can be generated.
	 * 
	 * Ought to be private. Made public for testing. 
	 * 
	 * @param numPts  	number of points
	 * @param rand      Random object to allow seeding of the random number generator
	 * @throws IllegalArgumentException if numPts < 1
	 */
	public static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException
	{ 
		if (numPts<1) {
			throw new IllegalArgumentException("Too few points");
		}
		Random gen = new Random(rand.nextInt(10));
		Point[] retThis= new Point[numPts];
		for(int i=0;i<numPts;++i) {
			retThis[i]=new Point(gen.nextInt(101)-50,gen.nextInt(101)-50);
		}
 
		return retThis;
	}
}
