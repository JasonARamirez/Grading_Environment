package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
//import java.lang.NumberFormatException;
import java.util.InputMismatchException;
//import java.lang.IllegalArgumentException; 


/**
 *  
 * @author Justin Thomas
 *
 */

/**
 * 
 * This class implements insertion sort.   
 *
 */

public class InsertionSorter extends AbstractSorter 
{
	// Other private instance variables if you need ... 
	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/**
	 * Constructor takes an array of points. 
	 * 
	 * @param pts  
	 */
	public InsertionSorter(Point[] pts) 
	{
		super(pts);
		algorithm="Insertion";
		outputFileName="insertion.txt";
	}	

	
	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public InsertionSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		super(inputFileName);		
		algorithm="Insertion";
		outputFileName="insertion.txt";
		
		
	}
	
	
	/** 
	 * Perform insertion sort on the array points[] of the parent class AbstractSorter.  
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 */
	@Override 
	public void sort(int order)
	{
		sortByAngle=false;
		sortingTime=System.nanoTime();
		if(order==1) {
			 int n = points.length;
		        for (int i=1; i<n; ++i)
		        {
		            Point key = points[i];
		            int j = i-1;
		            while (j>=0 && key.compareTo(points[j])==-1)
		            {
		                points[j+1] = points[j];
		                j = j-1;
		            }
		            points[j+1] = key;
		        }
		}
		else {
			sortByAngle=true;
			setComparator();
			 int n = points.length;
		        for (int i=1; i<n; ++i)
		        {
		            Point key = points[i];
		            int j = i-1;
		            while (j>=0 && pointComparator.compare(points[j],key)==-1)
		            {
		                points[j+1] = points[j];
		                j = j-1;
		            }
		            points[j+1] = key;
		        }

		}
	}		
}
