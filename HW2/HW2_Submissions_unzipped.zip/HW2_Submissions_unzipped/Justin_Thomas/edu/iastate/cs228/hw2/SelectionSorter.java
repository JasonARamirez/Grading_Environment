package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 


/**
 *  
 * @author Justin Thomas
 *
 */

/**
 * 
 * This class implements selection sort.   
 *
 */

public class SelectionSorter extends AbstractSorter
{
	// Other private instance variables if you need ... 
	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/**
	 * Constructor takes an array of points.
	 *  
	 * @param pts  
	 */
	public SelectionSorter(Point[] pts)  
	{
		super(pts);		
		algorithm="Selection";
		outputFileName="selection.txt"; 
	}	

	
	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public SelectionSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		super(inputFileName);		
		algorithm="Selection";
		outputFileName="selection.txt";
	}
	
	
	/** 
	 * Apply selection sort on the array points[] of the parent class AbstractSorter.  
	 *
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{
		sortByAngle=false;
		sortingTime=System.nanoTime();
		if(order==1) {
			Point tmpMin=points[0];
			for(int i=0;i<points.length-1;++i){
				int count=i;
				tmpMin=points[i];
				for(int k=i+1;k<points.length;++k) {
					if(points[k].compareTo(tmpMin)==-1) {
						count=k;
						tmpMin=points[k];
					}
				}
				swap(count,i);
			}
		}
		else {
			sortByAngle=true;
			setComparator();
			Point tmpMin=points[0];
			for(int l=0;l<points.length-1;++l){
				int count=l;
				tmpMin=points[l];
				for(int m=l+1;m<points.length;++m) {
					if((pointComparator.compare(points[m],tmpMin)==-1)) {
						count=m;
						tmpMin=points[m];
				}
			}
			swap(count,l);
			}
			
			
		}
	}	
}
