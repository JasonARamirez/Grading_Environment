package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 

/**
 *  
 * @author Justin Thomas
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	// Other private instance variables if you need ... 
	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/** 
	 * Constructor accepts an input array of points. 
	 * in the array. 
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		super(pts);
		algorithm="Merge";
		outputFileName="merge.txt";
	}
	
	
	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public MergeSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		super(inputFileName);		
		algorithm="Merge";
		outputFileName="merge.txt";
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{
		if(order==1) {
			sortByAngle=false;
		}
		else {
			sortByAngle=true;
		}
		sortingTime=System.nanoTime();
		mergeSortRec(points);
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts)
	{
		if(pts.length==2) {
			if(sortByAngle) {
				setComparator();
				if(pointComparator.compare(pts[1],pts[0])==-1) {
					Point tmp=pts[0];
					pts[0]=pts[1];
					pts[1]=tmp;
				}
			}
			else {
				if(pts[1].compareTo(pts[0])==-1) {
					Point tmp=pts[0];
					pts[0]=pts[1];
					pts[1]=tmp;
				}
			}
		}
		else {
			Point[] tempL = new Point[pts.length/2];
			Point[] tempR = new Point[pts.length/2];
			for(int i=0;i<pts.length/2;++i) {
				tempL[i]=pts[i];
			}
			for(int j=0;j<pts.length/2;++j) {
				tempR[j]=pts[j+pts.length/2];
			}
			mergeSortRec(tempR);
			mergeSortRec(tempL);
		}
	}

	
	// Other private methods in case you need ...

}
