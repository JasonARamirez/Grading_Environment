package edu.iastate.cs228.hw2;


import java.io.FileNotFoundException;
import java.lang.NumberFormatException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 


/**
 *  
 *@author Michael Arnold
 *
 */

/**
 * 
 * This class implements the version of the quicksort algorithm presented in the lecture.   
 *
 */

public class QuickSorter extends AbstractSorter
{
	

		
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/** 
	 * Constructor accepts an input array of points. 
	 *   
	 * @param pts   input array of integers
	 */
	public QuickSorter(Point[] pts)
	{
		
		super(pts);
		algorithm="Quick Sort";
		
	}
		

	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public QuickSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		 
		super(inputFileName);
		algorithm="Quick Sort";
	}


	/**
	 * Carry out quicksort on the array points[] of the AbstractSorter class.  
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{

   if (points == null || points.length == 0) 
   {
        return;
    }
    
    int length = points.length;
    long start = System.nanoTime();
    quickSort(0, length - 1,order);
    sortingTime = System.nanoTime() - start;

	}
	
	
	/**
	 * Operates on the subarray of points[] with indices between first and last. 
	 * 
	 * @param first  starting index of the subarray
	 * @param last   ending index of the subarray
	 */

    private void quickSort(int lowerIndex, int higherIndex, int order) {
    	
        int i = lowerIndex;
        int j = higherIndex;
   
        Point pivot = points[lowerIndex+(higherIndex-lowerIndex)/2];
        PolarAngleComparator p=new PolarAngleComparator(lowestPoint);
   
        while (i <= j)
        {
        
        	if(order==1){
            while (points[i].compareTo(pivot) < 0)
            {
                i++;
            }
            while (pivot.compareTo(points[j]) <0)
            {
                j--;
            }
        	}else if(order==2)
        	{
        		
        		 while (p.compare(points[i], pivot) < 0)
        		 {
                     i++;
                 }
        		
                 while (p.compare(pivot, points[j]) <0)
                 {
                     j--;
                 }
        	}
            if (i <= j) 
            {
                exchangeNumbers(i, j);
                
                i++;
                j--;
            }
        }
       
        if (lowerIndex < j)
            quickSort(lowerIndex, j,order);
        if (i < higherIndex)
            quickSort(i, higherIndex,order);
        
        
      
        
    }
	/**
	 * Operates on the subarray of points[] with indices between first and last.
	 * 
	 * @param first
	 * @param last
	 * @return
	 */
	  private void exchangeNumbers(int i, int j) {
	        Point temp = points[i];
	        points[i] = points[j];
	        points[j] = temp;
	    }
	
}
