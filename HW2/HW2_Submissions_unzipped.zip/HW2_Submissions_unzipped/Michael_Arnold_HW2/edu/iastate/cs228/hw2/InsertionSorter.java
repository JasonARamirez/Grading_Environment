package edu.iastate.cs228.hw2;


import java.io.FileNotFoundException;
import java.lang.NumberFormatException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 


/**
 *  
 * @author Michael Arnold
 *
 */

/**
 * 
 * This class implements insertion sort.   
 *
 */

public class InsertionSorter extends AbstractSorter 
{
	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/**
	 * Constructor takes an array of points. 
	 * 
	 * @param pts 
	 *  
	 */
	public InsertionSorter(Point[] pts) 
	{
		 
		super(pts);
		algorithm="Insertion Sort";
	}	

	
	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public InsertionSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		 
		super(inputFileName);
		algorithm="Insertion Sort";
	}
	
	
	/** 
	 * Perform insertion sort on the array points[] of the parent class AbstractSorter.  
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 */
	@Override 
	public void sort(int order)
	{
		 
		PolarAngleComparator p=new PolarAngleComparator(lowestPoint);
		long start = System.nanoTime();
		  
		  int n = points.length;
	        for (int j = 1; j < n; j++)
	        {
	            Point key = points[j];
	            int i = j-1;
	            if(order==1)
	            {
	            while ( (i > -1) && ( key.compareTo(points[i])<0 ) )
	            	{
	                	points [i+1] = points [i];
	                	i--;
	            	}
	            }
	            else if(order==2)
	            {
	            	
	            	  while ( (i > -1) && ( p.compare(key, points[i])<0 ) ) {
	  	                points [i+1] = points [i];
	  	                i--;
	  	            }
	            }
	            points[i+1] = key;
	            
	        }
		
	        
		  
		  sortingTime = System.nanoTime() - start;
		  
	}		
}
