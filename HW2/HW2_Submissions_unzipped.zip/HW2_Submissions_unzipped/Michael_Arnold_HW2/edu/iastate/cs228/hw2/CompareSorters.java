package edu.iastate.cs228.hw2;


/**
 *  
 * @author
 *
 */

/**
 * 
 * This class executes four sorting algorithms: selection sort, insertion sort, mergesort, and
 * quicksort, over randomly generated integers as well integers from a file input. It compares the 
 * execution times of these algorithms on the same input. 
 *
 */

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.Random; 


public class CompareSorters 
{
	public static PolarAngleComparator pac;
	public static Point referencePoint;
	/**
	 * Repeatedly take integer sequences either randomly generated or read from files. 
	 * Perform the four sorting algorithms over each sequence of integers, comparing 
	 * points by x-coordinate or by polar angle with respect to the lowest point.  
	 * 
	 * @param args
	 * @author Michael Arnold
	 **/
	public static void main(String[] args) 
	{		
		// TODO 
		// 
		// Conducts multiple sorting rounds. In each round, performs the following: 
		// 
		//    a) If asked to sort random points, calls generateRandomPoints() to initialize an array 
		//       of random points. 
		//    b) Reassigns to elements in the array sorters[] (declared below) the references to the 
		//       four newly created objects of SelectionSort, InsertionSort, MergeSort and QuickSort. 
		//    c) Based on the input point order, carries out the four sorting algorithms in a for 
		//       loop that iterates over the array sorters[], to sort the randomly generated points
		//       or points from an input file.  
		//    d) Meanwhile, prints out the table of runtime statistics.
		// 
		// A sample scenario is given in Section 2 of the assignment description. 
		// 	

		Scanner scan=new Scanner(System.in);
		boolean loop=true;
		int order=0;
		int numPts=0;
		int key=0;
		int trial=0;
		Random rand=new Random();
		System.out.println("Comparison of Four Sorting Algorithms\n");
		System.out.println("keys: 1 (random integers) 2 (file input) 3 (exit)");
		System.out.println("order: 1 (by x-coordinate) 2 (by polar angle)\n");
		while(loop){
			AbstractSorter[] sorters = new AbstractSorter[4];
			System.out.print("Trial "+(trial+1)+" => ");
			System.out.print("Enter Key: ");
			key=scan.nextInt();
			if(key==1){
			System.out.print("Enter Number of random points: ");
			numPts=scan.nextInt();
			System.out.print("Order used in sorting: ");
			order=scan.nextInt();
			System.out.println("");
		
			
				Point[] sortPts=generateRandomPoints(numPts,rand);
				SelectionSorter ss=new SelectionSorter(sortPts);
				MergeSorter ms=new MergeSorter(sortPts);
				InsertionSorter is=new InsertionSorter(sortPts);
				QuickSorter qs=new QuickSorter(sortPts);
				sorters[0]=ss;
				sorters[1]=is;
				sorters[2]=ms;
				sorters[3]=qs;
				sort(sorters,order);
				trial++;
			}
			else if(key==2){
				System.out.println("Points from a file");
				String file="";
			    System.out.print("File Name: ");
			    file=scan.next();
			    System.out.print("Order used in sorting: ");
				order=scan.nextInt();
			    System.out.println("");
				try {
					SelectionSorter	ss = new SelectionSorter(file);
					MergeSorter ms=new MergeSorter(file);
					 InsertionSorter is=new InsertionSorter(file);
					 QuickSorter qs=new QuickSorter(file);
					    sorters[0]=ss;
						sorters[1]=is;
						sorters[2]=ms;
						sorters[3]=qs;
				} catch (InputMismatchException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				sort(sorters,order);
				trial++;
			}
			else if(key==3){
			loop=false;
			}

		
		
	}
	}
	
	/**
	 * This method generates a given number of random points to initialize randomPoints[].
	 * The coordinates of these points are pseudo-random numbers within the range 
	 * [-50,50] � [-50,50]. Please refer to Section 3 of assignment description document on how such points can be generated.
	 * 
	 * Ought to be private. Made public for testing. 
	 * 
	 * @param numPts  	number of points
	 * @param rand      Random object to allow seeding of the random number generator
	 * @throws IllegalArgumentException if numPts < 1
	 */
	public static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException
	{ 
		
		 Point[] pnts=new Point[numPts];
		
		for(int i=0;i<numPts;i++){
			int rand1 =	rand.nextInt(101)-50;
			int rand2 =	rand.nextInt(101)-50;
			pnts[i]=new Point(rand1,rand2);
		}
		return pnts; 
	 
	}
	public static void sort(AbstractSorter[] sorters, int order)
	{
		String format = "%-32s%-10s%-16s\n";
	
		System.out.format(format, "algorithm","size","time (ns)");
		
		System.out.println("-----------------------------------------------------");
		for(int i=0;i<sorters.length;i++)
		{
			sorters[i].findLowestPoint();
			sorters[i].sort(order);
			try {
				sorters[i].writePointsToFile(order);
			} catch (FileNotFoundException e) {
		
				e.printStackTrace();
			}
			sorters[i].stats(format);
		}
		System.out.println("-----------------------------------------------------");
		System.out.println("");
	}
	
}
