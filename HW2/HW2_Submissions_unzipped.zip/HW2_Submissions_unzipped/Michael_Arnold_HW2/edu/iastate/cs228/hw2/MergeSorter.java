package edu.iastate.cs228.hw2;


import java.io.FileNotFoundException;
import java.lang.NumberFormatException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 

/**
 *  
 * @author Michael Arnold
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{

	private Point[] tempMergArr;
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/** 
	 * Constructor accepts an input array of points. 
	 * in the array. 
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
	 
		super(pts);
		tempMergArr=pts.clone();
		algorithm="Merge Sort";
		
	}
	
	
	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public MergeSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		
		super(inputFileName);
		algorithm="Merge Sort";
		tempMergArr=points.clone();
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{

		long start = System.nanoTime();
        doMergeSort(0,points.length-1,order);
        sortingTime = System.nanoTime() - start;
      
        
	}
	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void doMergeSort(int lowerIndex, int higherIndex,int order) {
        
        if (lowerIndex < higherIndex)
        {
            int middle = lowerIndex + (higherIndex - lowerIndex) / 2;
            doMergeSort(lowerIndex, middle,order);
            doMergeSort(middle + 1, higherIndex,order);
            mergeParts(lowerIndex, middle, higherIndex, order);
        }
    }
 
    private void mergeParts(int lowerIndex, int middle, int higherIndex,int order) {
 
        for (int i = lowerIndex; i <= higherIndex; i++) {
            tempMergArr[i] = points[i];
        }
        PolarAngleComparator p=new PolarAngleComparator(lowestPoint);
        int i = lowerIndex;
        int j = middle + 1;
        int k = lowerIndex;
        while (i <= middle && j <= higherIndex)
        {
        	if(order==1){
            if (tempMergArr[i].compareTo(tempMergArr[j]) <= 0)
            {
                points[k] = tempMergArr[i];
                i++;
            } else
            {
                points[k] = tempMergArr[j];
                j++;
            }
            k++;
            }
        	else if(order==2)
        	{

                if (p.compare(tempMergArr[i], tempMergArr[j]) <= 0) {
                    points[k] = tempMergArr[i];
                    i++;
                } else {
                    points[k] = tempMergArr[j];
                    j++;
                }
                k++;
            }
        }
        while (i <= middle) 
        {
            points[k] = tempMergArr[i];
            k++;
            i++;
        }
 
    }



}
