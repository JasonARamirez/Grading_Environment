package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 

/**
 *  
 * @author Timothy Hoffman
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	// Other private instance variables if you need ... 
	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/** 
	 * Constructor accepts an input array of points. 
	 * in the array. 
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		super(pts);
		super.outputFileName = "merge.txt";
		super.algorithm = "merge sort"; 
	}
	
	
	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public MergeSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		super(inputFileName);
		super.outputFileName = "merge.txt";
		super.algorithm = "merge sort";  
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{
		// TODO 
		if(order < 1 || order > 2){
			throw new IllegalArgumentException();
		}
		
		if(order == 1){
			super.sortByAngle = false;
		}
		else{
			super.sortByAngle = true;
		}
		this.setComparator(order);
			
			if(points == null || points.length == 0){
				throw new IllegalArgumentException();
			}
			
		this.setComparator(order);
			this.sortingTime = System.nanoTime();
		mergeSortRec(points);
			this.sortingTime = System.nanoTime() - this.sortingTime;
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts)
	{
	
		Point[] tmp = new Point[points.length];
		mergeSortRecWithIndex( pts, tmp, 0, points.length-1);
		
	}
	
	private void mergeSortRecWithIndex(Point[] pts,Point[] tmp, int first, int last){
		if ( first < 0 || last >= pts.length )
		      throw new IllegalArgumentException("index out of bound");
		    if ( first >= last )  return; // a subarray of size 1 is already sorted by itself.

		    int i, j, k;
		    int mid = (first + last) / 2; // partition index


	
		    mergeSortRecWithIndex(pts, tmp, first, mid); // sorts each subarray
		    mergeSortRecWithIndex(pts, tmp, mid+1, last);

		    k = first;
		    for ( i = first, j = mid+1; i <= mid && j <= last; )
		    { 
		      if (pointComparator.compare(pts[i],pts[j]) == -1)
		        tmp[k++] = pts[i++];
		      else
		        tmp[k++] = pts[j++];
		    }  // merges two sorted subarrays

		    while ( i <= mid ) // at most one of the two while loops gets executed
		        tmp[k++] = pts[i++];
		    while ( j <= last ) // copies the rest of one subarray
		        tmp[k++] = pts[j++];
		    if ( k != last + 1 )
		      throw new RuntimeException("Error in index");

		    for ( k = first; k <= last; k++ ) // keeps the results in arr
		        pts[k] = tmp[k];
	}
	
	// Other private methods in case you need ...

}
