package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 


/**
 *  
 * @author Timothy Hoffman
 *
 */

/**
 * 
 * This class implements insertion sort.   
 *
 */

public class InsertionSorter extends AbstractSorter 
{
	// Other private instance variables if you need ... 
	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/**
	 * Constructor takes an array of points. 
	 * 
	 * @param pts  
	 */
	public InsertionSorter(Point[] pts) 
	{
		super(pts);
		super.outputFileName = "insert.txt";
		super.algorithm = "insertion sort";
	}	

	
	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public InsertionSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		super(inputFileName);
		super.outputFileName = "insert.txt";
		super.algorithm = "insertion sort";
	}
	
	
	/** 
	 * Perform insertion sort on the array points[] of the parent class AbstractSorter.  
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 */
	@Override 
	public void sort(int order)
	{
		if(order < 1 || order > 2){
			throw new IllegalArgumentException();
		}
		
		if(order == 1){
			sortByAngle = false;
		}
		else{
			sortByAngle = true;
		}
		this.setComparator(order);
			this.sortingTime = System.nanoTime();
			if(points == null || points.length == 0){
				throw new IllegalArgumentException();
			}
			
			for(int i = 1; i < points.length; i++){
				Point t = points[i];
				for(int j = i-1; j >= 0 && pointComparator.compare(t, points[j]) < 0; j--){
					this.swap(j+1, j);
				}
			}
		
			this.sortingTime = System.nanoTime()-this.sortingTime;
	}		
}
