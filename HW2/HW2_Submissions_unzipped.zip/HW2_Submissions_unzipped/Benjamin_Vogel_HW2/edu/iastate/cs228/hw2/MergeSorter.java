package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 

/**
 *  
 * @author Benjamin Vogel
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	// Other private instance variables if you need ... 
	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/** 
	 * Constructor accepts an input array of points. 
	 * in the array. 
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		super(pts);
		algorithm = "merge sort";
		outputFileName = "merge.txt";
	}
	
	
	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 */
	public MergeSorter(String inputFileName) throws FileNotFoundException
	{
		super(inputFileName);
		algorithm = "merge sort";
		outputFileName = "merge.txt";
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{
		if(order == 1 || order == 2)
        {
            long startTime = System.nanoTime();
            mergeSortRec(points, order);
            sortingTime = System.nanoTime() - startTime;
        }

        else
        {
            throw new IllegalArgumentException();
        }
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts, int order)
	{
       setComparator(order);
	   mergeSortRecDetailed(pts, 0, pts.length -1);
	}

	// Other private methods in case you need ...

    /**
     * Calls a more detailed version of mergeSortRec. Allows to pass in a left and right
     * integer to help with recursively calling mergeSortRec. After separating the array
     * into half, it then calls merge to merge the sorted arrays together.
     *
     *
     * @param pts point array
     * @param left leftmost index of the array
     * @param right rightmost index of the array
     */
    private void mergeSortRecDetailed(Point[] pts, int left,  int right)
    {
        if(left < right)
        {
            int middle = (left + right) / 2;

            mergeSortRecDetailed(pts, left, middle);
            mergeSortRecDetailed(pts, middle + 1, right);

            merge(pts, left, middle, right);
        }

    }

    /**
     * Merges the two sorted arrays. Creates two temporary arrays based on the provided
     * integers of left, middle, and right. It then goes through and copies the values from the original array
     * into the temp arrays based on the given indices. After filling the new arrays, it then compares the values
     * at each part of the two temporary arrays. Whichever has the lesser value gets placed back into the original
     * array. This continues until the original array is sorted.
     *
     *
     * @param pts point array
     * @param left the leftmost index of the array
     * @param middle the middle index of the array
     * @param right the rightmost index of the array
     */
    private void merge(Point[] pts, int left, int middle, int right)
    {
        Point[] helper = new Point[pts.length];

        for(int i = left; i <= right; i++)
        {
            helper[i] = pts[i];
        }

        int i = left;
        int j = middle + 1;
        int k = left;

        while(i <= middle && j <= right)
        {
            if(pointComparator.compare(helper[i],helper[j]) == -1)
            {
                pts[k] = helper[i];
                i++;
            }
            else
            {
                pts[k] = helper[j];
                j++;
            }

            k++;
        }

        while(i <= middle)
        {
            pts[k] = helper[i];
            k++;
            i++;
        }
    }

}
