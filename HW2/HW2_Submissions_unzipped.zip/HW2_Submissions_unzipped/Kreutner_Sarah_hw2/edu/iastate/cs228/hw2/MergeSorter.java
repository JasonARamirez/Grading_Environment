package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException;

/**
 *  
 * @author Sarah Kreutner
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.
 *
 */

public class MergeSorter extends AbstractSorter {
	// Other private instance variables if you need ...

	/**
	 * The two constructors below invoke their corresponding superclass
	 * constructors. They also set the instance variables algorithm and
	 * outputFileName in the superclass.
	 */

	/**
	 * Constructor accepts an input array of points. in the array.
	 * 
	 * @param pts
	 *            input array of integers
	 */
	public MergeSorter(Point[] pts) {
		super(pts);
		algorithm = "merge sort";
		outputFileName = "merge.txt";
	}

	/**
	 * Constructor reads points from a file.
	 * 
	 * @param inputFileName
	 *            name of the input file
	 */
	public MergeSorter(String inputFileName) throws FileNotFoundException, InputMismatchException {
		super(inputFileName);
		algorithm = "merge sort";
		outputFileName = "merge.txt";
	}

	/**
	 * Perform mergesort on the array points[] of the parent class
	 * AbstractSorter.
	 * 
	 * @param order
	 *            1 by x-coordinate 2 by polar angle
	 *
	 */
	@Override
	public void sort(int order) {
		long start = System.nanoTime();
		setComparator(order);
		mergeSortRec(points);
		sortingTime = System.nanoTime() - start;
	}

	/**
	 * This is a recursive method that carries out mergesort on an array pts[]
	 * of points. One way is to make copies of the two halves of pts[],
	 * recursively call mergeSort on them, and merge the two sorted subarrays
	 * into pts[].
	 * 
	 * @param pts
	 *            point array
	 */
	private void mergeSortRec(Point[] pts) {
		if (pts.length <= 1) {
			return;
		}
		mergeSortRec(pts, 0, pts.length - 1);
	}

	private void mergeSortRec(Point[] arr, int first, int last) {
		if (arr.length <= 1) {
			return;
		}
		Point[] tmp = new Point[arr.length];
		if (first < 0 || last >= arr.length)
			throw new IllegalArgumentException("index out of bound");
		if (first >= last)
			return; // a subarray of size 1 is already sorted by itself.

		int i, j, k;
		int mid = (first + last) / 2; // partition index

		mergeSortRec(arr, first, mid); // sorts each subarray
		mergeSortRec(arr, mid + 1, last);

		k = first;
		for (i = first, j = mid + 1; i <= mid && j <= last;) {
			if (pointComparator.compare(arr[i], arr[j]) == -1) // ||
																// pointComparator.compare(arr[i],
																// arr[j]) == 0
				tmp[k++] = arr[i++];
			else
				tmp[k++] = arr[j++];
		} // merges two sorted subarrays

		while (i <= mid) // at most one of the two while loops gets executed
			tmp[k++] = arr[i++];
		while (j <= last) // copies the rest of one subarray
			tmp[k++] = arr[j++];
		if (k != last + 1)
			throw new RuntimeException("Error in index");
		
System.out.println("First: "+first+" Last: "+last);

		for (k = first; k <= last; k++) {
			// keeps the results in arr
			arr[k] = tmp[k];
			System.out.println(arr[k]);
		}
			
			
		
		
		

	}
	//// If tmp is not sorted, split into two arrays; this part seems to be
	//// working.
	// int mid = (tmp.length) / 2;
	// Point[] h1 = new Point[mid]; // first half
	// for (int c = 0; c<mid; c++) { // copy first half of tmp
	// h1[c] = tmp[c];
	// }
	// Point[] h2 = new Point[tmp.length - mid]; // second half
	// for (int d = 0; d<tmp.length - mid; d++) {
	// h2[d] = tmp[d+mid]; //copy second half of tmp
	// }
	//
	// mergeRec(h1); // sorts each subarray
	// mergeRec(h2); // -> This seems to be the problem area!
	//
	// tmp = merge( );

	private Point[] merge(Point[] h1, Point[] h2) {
		Point[] result = new Point[h1.length + h2.length];
		int i = 0;
		int j = 0;
		int k = 0;

		while (j < h1.length && k < h2.length) {
			if (pointComparator.compare(h1[j], h2[k]) == -1) {
				result[i] = h1[j];
				j++;
			} else {
				result[i] = h2[k];
				k++;
			}
			i++;
		}

		while (j < h1.length) {
			result[i] = h1[j];
			j++;
			i++;
		}

		while (k < h2.length) {
			result[i] = h2[k];
			k++;
			i++;
		}
		return result;
	}
}
