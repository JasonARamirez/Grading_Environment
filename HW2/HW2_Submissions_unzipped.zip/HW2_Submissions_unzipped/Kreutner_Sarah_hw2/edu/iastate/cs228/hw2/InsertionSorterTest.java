package edu.iastate.cs228.hw2;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.Arrays;
import java.util.InputMismatchException;

import org.junit.Test;

public class InsertionSorterTest {
	Point lowest = new Point(-6,-8);
	Point[] ps = {new Point(1,5), new Point(4,3), new Point(-2,4), new Point(7,2),
				new Point(3,-2), new Point(0,0), lowest};
	Point ref1 = new Point(-2,-3);
	PolarAngleComparator PAC = new PolarAngleComparator(ref1);	
	Point pA = new Point(3,-2);
	Point pB = new Point(1,5);
	Point pC = new Point(0,-1);
	Point pD = new Point(4,3);
	InsertionSorter I = new InsertionSorter(ps);

	@Test
	public void constructorTests() {
		assertTrue(Arrays.equals(ps, I.points));
		assertFalse(I.sortByAngle);
		assertEquals(I.sortingTime, 0);
		assertEquals(I.algorithm, "insertion sort");
		assertEquals(I.outputFileName, "insert.txt");
		assertEquals(I.getLowest(), lowest);
		
		Point[] n = null;
		try {
			@SuppressWarnings("unused")
			InsertionSorter j = new InsertionSorter(n);
			fail();
		}
		catch (Exception e) {
			assertEquals(e.getClass(), IllegalArgumentException.class);
		}
		Point[] empty = {};
		try {
			@SuppressWarnings("unused")
			InsertionSorter k = new InsertionSorter(empty);
			fail();
		}
		catch (Exception e) {
			assertEquals(e.getClass(), IllegalArgumentException.class);
		}
	}
	
	@Test
	public void readFileTests() {
		try {
			InsertionSorter f = new InsertionSorter("src/edu/iastate/cs228/hw2/input1.txt");
			assertTrue(Arrays.equals(ps, f.points));
			assertEquals(lowest, f.getLowest());
			
			InsertionSorter g = new InsertionSorter("src/edu/iastate/cs228/hw2/points.txt");
			String s = "";
			for (Point p: g.points) {
				s+=p.toString()+" ";
			}
			assertEquals(s, "(0, 0) (-3, -9) (0, -10) (8, 4) (3, 3) (-6, 3) (-2, 1) (10, 5) (-7, -10) (5, -2) (7, 3) (10, 5) (-7, -10) (0, 8) (-1, -6) (-10, 0) (5, 5) ");
		}
		catch (Exception e) {
			System.out.println(e.getClass()+" "+e.getMessage());
			fail();
		}
		try {
			@SuppressWarnings("unused")
			InsertionSorter odd = new InsertionSorter("src/edu/iastate/cs228/hw2/input2.txt");
			fail();
		}
		catch (Exception e) {
			assertEquals(e.getClass(), InputMismatchException.class);
			assertEquals(e.getMessage(), "Odd number of integers");
		}
		
	}
	

	
	@Test
	public void spacingTests() {
		System.out.println(I.stats());
		System.out.println(I.toString());
	}
	
	@Test
	public void setComparatorTests() {
		assertFalse(I.sortByAngle);
		I.setComparator(2);
		assertEquals(I.pointComparator.getClass(), PolarAngleComparator.class);
		I.setComparator(1);
		try {
			System.out.println(I.pointComparator.compare(pA, pB));
			System.out.println(I.toString());
		}
		catch (Exception e) {
			System.out.println(e.getClass() + " "+ e.getMessage());
			fail();
		}
	}
	
	@Test
	public void writeStringTests() {
		I.setComparator(2);
		System.out.println(I.toPAString());
		try {
			I.writePointsToFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	


	@Test	
	public void sortXTest() {
		System.out.println("Sort by X below");
		Point[]	cheese = new Point[17];
		Point[] correctX = new Point[17];
		
		cheese[0] = new Point(0,0);
		cheese[1] = new Point(-3,-9);
		cheese[2] = new Point(0,-10);
		cheese[3] = new Point(8,4);
		cheese[4] = new Point(3,3);
		cheese[5] = new Point(-6,3);
		cheese[6] = new Point(-2,1);
		cheese[7] = new Point(10,5);
		cheese[8] = new Point(-7,-10);
		cheese[9] = new Point(5,-2);
		cheese[10] = new Point(7,3);
		cheese[11] = new Point(10,5);
		cheese[12] = new Point(-7,-10);
		cheese[13] = new Point(0,8);
		cheese[14] = new Point(-1,-6);
		cheese[15] = new Point(-10,0);
		cheese[16] = new Point(5,5);
		
		InsertionSorter dip = new InsertionSorter(cheese);
		
		correctX[0] = new Point(-10,0);
		correctX[1] = new Point(-7,-10);
		correctX[2] = new Point(-7,-10);
		correctX[3] = new Point(-6,3);
		correctX[4] = new Point(-3,-9);
		correctX[5] = new Point(-2,1);
		correctX[6] = new Point(-1,-6);
		correctX[7] = new Point(0,-10);
		correctX[8] = new Point(0,0);
		correctX[9] = new Point(0,8);
		correctX[10] = new Point(3,3);
		correctX[11] = new Point(5,-2);
		correctX[12] = new Point(5,5);
		correctX[13] = new Point(7,3);
		correctX[14] = new Point(8,4);
		correctX[15] = new Point(10,5);
		correctX[16] = new Point(10,5);
		
		
		dip.sort(1);
		assertTrue(Arrays.equals(dip.points, correctX));
		System.out.println(dip.toString());
		System.out.println(dip.sortingTime + "\n");
	}	
	
	@Test	
	public void sortPolarTest()
	{
		System.out.println("Sort by Polar below");
		Point[] correctPolar = new Point[17];
		Point[] cheese = new Point[17];
		cheese[0] = new Point(0,0);
		cheese[1] = new Point(-3,-9);
		cheese[2] = new Point(0,-10);
		cheese[3] = new Point(8,4);
		cheese[4] = new Point(3,3);
		cheese[5] = new Point(-6,3);
		cheese[6] = new Point(-2,1);
		cheese[7] = new Point(10,5);
		cheese[8] = new Point(-7,-10);
		cheese[9] = new Point(5,-2);
		cheese[10] = new Point(7,3);
		cheese[11] = new Point(10,5);
		cheese[12] = new Point(-7,-10);
		cheese[13] = new Point(0,8);
		cheese[14] = new Point(-1,-6);
		cheese[15] = new Point(-10,0);
		cheese[16] = new Point(5,5);
		
		InsertionSorter dip = new InsertionSorter(cheese);
		
		correctPolar[0] = new Point(-7,-10);
		correctPolar[1] = new Point(-7,-10);
		correctPolar[2] = new Point(0,-10);
		correctPolar[3] = new Point(-3,-9);
		correctPolar[4] = new Point(-1,-6);
		correctPolar[5] = new Point(5,-2);
		correctPolar[6] = new Point(10,5);
		correctPolar[7] = new Point(10,5);
		correctPolar[8] = new Point(7,3);
		correctPolar[9] = new Point(8,4);
		correctPolar[10] = new Point(5,5);
		correctPolar[11] = new Point(3,3);
		correctPolar[12] = new Point(0,0);
		correctPolar[13] = new Point(-2,1);
		correctPolar[14] = new Point(0,8);
		correctPolar[15] = new Point(-6,3);
		correctPolar[16] = new Point(-10,0);
		
		dip.sort(2);
		assertTrue(Arrays.equals(dip.points, correctPolar));
		System.out.println(dip.toString());
		System.out.println(dip.sortingTime + "\n");
		
	}
	

}