package edu.iastate.cs228.hw2;

public class TestErrors {

	public static void main(String[] args) {
		System.out.println("Hi");

	}

}
