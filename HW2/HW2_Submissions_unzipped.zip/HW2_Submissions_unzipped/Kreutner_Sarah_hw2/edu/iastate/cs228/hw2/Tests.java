package edu.iastate.cs228.hw2;

public class Tests {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Point[] ps = {new Point(1,5), new Point(4,3), new Point(-2,4), new Point(7,2),
					new Point(3,-2), new Point(0,0), new Point(-2,-3)};
		
		PolarAngleComparator PAC = new PolarAngleComparator(new Point(-2,-3));
		System.out.println(PAC.compare(ps[0], ps[4]));
		
		
	}

}