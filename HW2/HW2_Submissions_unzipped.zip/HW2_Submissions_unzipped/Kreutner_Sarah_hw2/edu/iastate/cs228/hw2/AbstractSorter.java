package edu.iastate.cs228.hw2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *  
 * @author Sarah Kreutner
 *
 */

/**
 * 
 * This abstract class is extended by SelectionSort, InsertionSort, MergeSort,
 * and QuickSort. It stores the input (later on the sorted) sequence and records
 * the employed sorting algorithm, the comparison method, and the time spent on
 * sorting.
 *
 */

public abstract class AbstractSorter {

	protected Point[] points; // Array of points operated
								// on by a sorting
								// algorithm.
	// The number of points is given by points.length.

	protected String algorithm = null; // "selection sort", "insertion sort",
										// "merge sort", or "quick sort".
										// Initialized by a subclass
										// constructor.
	protected boolean sortByAngle; // true if current/last sort was done by
									// polar angle
									// and false
									// if by x-coordinate

	protected String outputFileName; // "select.txt", "insert.txt", "merge.txt",
										// or "quick.txt"

	protected long sortingTime; // execution time in nanoseconds.

	protected Comparator<Point> pointComparator; // comparator which compares
													// polar angle if
													// sortByAngle == true and
													// x-coordinate if
													// sortByAngle == false

	private Point lowestPoint; // lowest point in the array, or in case of a
								// tie, the
								// leftmost of the lowest points. This point is
								// used
								// as the reference point for polar angle based
								// comparison.

	// Add other protected or private instance variables you may need.

	protected AbstractSorter() {
		// No implementation needed. Provides a default super constructor to
		// subclasses.
		// Removable after implementing SelectionSorter, InsertionSorter,
		// MergeSorter, and QuickSorter.
	}

	/**
	 * This constructor accepts an array of points as input. Copy the points
	 * into the array points[]. Sets the instance variable lowestPoint.
	 * 
	 * @param pts
	 *            input array of points
	 * @throws IllegalArgumentException
	 *             if pts == null or pts.length == 0.
	 */
	protected AbstractSorter(Point[] pts) throws IllegalArgumentException {
		if (pts == null || pts.length == 0) {
			throw new IllegalArgumentException();
		}
		points = new Point[pts.length];
		for (int i = 0; i < pts.length; i++) {
			Point p = new Point(pts[i]);
			points[i] = p;
		}
		lowestPoint = findLowest(pts);

	}

	/**
	 * Helper method that finds the lowest point for the constructor
	 * 
	 * @param pts
	 *            the given point[]
	 * @return
	 */
	private Point findLowest(Point[] pts) {
		Point result = pts[0];
		for (int i = 1; i < pts.length; i++) {
			if (pts[i].getY() < result.getY()) {
				result = pts[i];
			} else if (pts[i].getY() == result.getY()) {
				if (pts[i].getX() < result.getX()) {
					result = pts[i];
				}
			}
		}
		return result;
	}

	/**
	 * This constructor reads points from a file. Sets the instance variables
	 * lowestPoint and outputFileName.
	 * 
	 * @param inputFileName
	 * @throws FileNotFoundException
	 * @throws InputMismatchException
	 *             when the input file contains an odd number of integers
	 */
	@SuppressWarnings("resource")
	protected AbstractSorter(String inputFileName) throws FileNotFoundException, InputMismatchException {
		Scanner s = new Scanner(new File(inputFileName));
		int c = 0;
		while (s.hasNextInt()) {
			s.nextInt();
			c++;
		}
		if (c % 2 != 0) {
			throw new InputMismatchException("Odd number of integers");
		}
		points = new Point[c / 2];
		s = new Scanner(new File(inputFileName));
		for (int i = 0; i < (c / 2); i++) {
			int x = s.nextInt();
			int y = s.nextInt();
			Point p = new Point(x, y);
			points[i] = p;
		}
		lowestPoint = findLowest(points);
	}

	/**
	 * Sorts the elements in points[].
	 * 
	 * a) in the non-decreasing order of x-coordinate if order == 1 b) in the
	 * non-decreasing order of polar angle w.r.t. lowestPoint if order == 2
	 * (lowestPoint will be at index 0 after sorting)
	 * 
	 * Sets the instance variable sortByAngle based on the value of order. Calls
	 * the method setComparator() to set the variable pointComparator and use it
	 * in sorting. Records the sorting time (in nanoseconds) using the
	 * System.nanoTime() method. (Assign the time to the variable sortingTime.)
	 * 
	 * @param order
	 *            1 by x-coordinate 2 by polar angle w.r.t lowestPoint
	 *
	 * @throws IllegalArgumentException
	 *             if order is less than 1 or greater than 2
	 */
	public abstract void sort(int order) throws IllegalArgumentException;

	/**
	 * Outputs performance statistics in the format:
	 * 
	 * <sorting algorithm> <size> <time>
	 * 
	 * For instance,
	 * 
	 * selection sort 1000 9200867
	 * 
	 * Use the spacing in the sample run in Section 2 of the assignment
	 * description.
	 */
	public String stats() {
		return this.algorithm + "\t\t" + points.length + "\t\t" + this.sortingTime;
	}

	/**
	 * Write points[] to a string. When printed, the points will appear in order
	 * of increasing index with every point occupying a separate line. The x and
	 * y coordinates of the point are displayed on the same line with exactly
	 * one blank space in between.
	 */
	@Override
	public String toString() {
		String result = "";
		for (Point p : points) {
			result += p.getX() + " " + p.getY();
			result += "\n";
		}
		return result;
	}

	/**
	 * 
	 * This method, called after sorting, writes point data into a file by
	 * outputFileName. It will be used for Mathematica plotting to verify the
	 * sorting result. The data format depends on sortByAngle. It is detailed in
	 * Section 4.1 of the assignment description assn2.pdf.
	 * 
	 * @throws IOException
	 */
	public void writePointsToFile() throws IOException {
		File f = new File(outputFileName);
		FileWriter writer = new FileWriter(f);
		try {
			if (sortByAngle == true) {
				writer.write(this.toPAString());
			} else {
				writer.write(this.toString());
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			writer.close();
		}

	}

	/**
	 * Formats polar-angle-sorted data for Mathematica Protected for testing
	 * 
	 * @return String where the first line displays
	 */
	protected String toPAString() {
		String s = lowestPoint.getX() + " " + lowestPoint.getY() + "\n";
		for (int i = 0; i < points.length; i++) {
			s += points[i].getX() + " " + points[i].getY() + " ";
			s += lowestPoint.getX() + " " + lowestPoint.getY() + " ";
			s += points[i].getX() + " " + points[i].getY() + " ";
			s += "\n";
		}
		return s;
	}

	/**
	 * Generates a comparator on the fly that compares by polar angle if
	 * sortByAngle == true and by x-coordinate if sortByAngle == false. Set the
	 * protected variable pointComparator to it. Need to create an object of the
	 * PolarAngleComparator class and call the compareTo() method in the Point
	 * class, respectively for the two possible values of sortByAngle.
	 * 
	 * @param order
	 */
	protected void setComparator(int order) {
		if (order == 1) { // sort by x-coordinate
			sortByAngle = false;
		} else if (order == 2) { // sort by polar angle
			sortByAngle = true;
		}
		if (sortByAngle == false) { // set comparator to XYComparator
			setXYComparator();
		} else if (sortByAngle == true) { // set comparator to
											// PolarAngleComparator
			pointComparator = new PolarAngleComparator(lowestPoint);
		}

	}

	/**
	 * Anonymous class that converts the Point.compare() method to an
	 * XYComparator object with one compare() method
	 */
	public void setXYComparator() {
		class XYComparator implements Comparator<Point> {
			@Override
			public int compare(Point a, Point b) {
				return a.compareTo(b);
			}
		}
		this.pointComparator = new XYComparator();
	}

	/**
	 * Swap the two elements indexed at i and j respectively in the array
	 * points[].
	 * 
	 * @param i Index of point to swap
	 * @param j Index of other point to swap
	 */
	protected void swap(int i, int j) {
		Point temp = points[i];
		points[i] = points[j];
		points[j] = temp;
	}

	/**
	 * Getter method for JUnit purposes
	 * 
	 * @return this Sorter's lowestPoint / referencePoint
	 */
	protected Point getLowest() {
		return lowestPoint;
	}
}
