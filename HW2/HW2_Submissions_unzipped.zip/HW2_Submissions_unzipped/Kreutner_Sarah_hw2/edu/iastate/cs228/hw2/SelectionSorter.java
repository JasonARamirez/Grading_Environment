package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException;

/**
 *  
 * @author Sarah Kreutner
 *
 */

/**
 * 
 * This class implements selection sort.
 *
 */

public class SelectionSorter extends AbstractSorter {
	// Other private instance variables if you need ...

	/**
	 * The two constructors below invoke their corresponding superclass
	 * constructors. They also set the instance variables algorithm and
	 * outputFileName in the superclass.
	 */

	/**
	 * Constructor takes an array of points.
	 * 
	 * @param pts
	 */
	public SelectionSorter(Point[] pts) {
		super(pts);
		sortByAngle = false;
		algorithm = "selection sort";
		outputFileName = "select.txt";
		sortingTime = 0;
	}

	/**
	 * Constructor reads points from a file.
	 * 
	 * @param inputFileName
	 *            name of the input file
	 */
	public SelectionSorter(String inputFileName) throws FileNotFoundException, InputMismatchException {
		super(inputFileName);
		sortByAngle = false;
		algorithm = "selection sort";
		outputFileName = "select.txt";
		sortingTime = 0;
	}

	/**
	 * Apply selection sort on the array points[] of the parent class
	 * AbstractSorter.
	 *
	 * @param order
	 *            1 by x-coordinate 2 by polar angle
	 *
	 */
	@Override
	public void sort(int order) {
		long start = System.nanoTime();
		setComparator(order);
		for (int i = 0; i < points.length; i++) {
			Point smallest = points[i];
			int smallestI = i;
			for (int j = i+1; j < points.length; j++) {
				if (pointComparator.compare(points[j], smallest) == -1) {
					smallest = points[j];
					smallestI = j;
				}

			}
			swap(i, smallestI);
		}

		//
		//
		//
		// for (int i = 0; i < points.length; i++) {
		// for (int j = i; j< points.length; j++) { // j should equal i+1
		// if (pointComparator.compare(points[j], points[i]) == -1) {
		// swap(j, i);
		// }
		// }
		// }
		sortingTime = System.nanoTime() - start;
	}

}
