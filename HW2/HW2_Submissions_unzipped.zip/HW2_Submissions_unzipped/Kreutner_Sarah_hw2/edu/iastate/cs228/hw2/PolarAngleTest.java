package edu.iastate.cs228.hw2;

import static org.junit.Assert.*;

import org.junit.Test;

public class PolarAngleTest {
	
	Point[] ps = {new Point(1,5), new Point(4,3), new Point(-2,4), new Point(7,2),
					new Point(3,-2), new Point(0,0), new Point(-2,-3)};
	Point ref1 = new Point(-2,-3);
	PolarAngleComparator PAC = new PolarAngleComparator(ref1);	
	Point pA = new Point(3,-2);
	Point pB = new Point(1,5);
	Point pC = new Point(0,-1);
	Point pD = new Point(4,3);
	@Test
	public void testPolarAngleP1Smaller() {
		assertEquals(PAC.comparePolarAngle(pA, pB), -1);
	}
	@Test
	public void tpaP2Smaller() {
		assertEquals(PAC.comparePolarAngle(pB, pA), 1);
	}
	@Test
	public void tpaSameAsRef() {
		assertEquals(PAC.comparePolarAngle(ref1, pA), -1);
	}
	@Test
	public void tpaSamePoint(){
		assertEquals(PAC.comparePolarAngle(pA, pA), 0);
	}
	
	@Test
	public void tCompareP1Smaller() {
		assertEquals(PAC.compare(pA, pB), -1);
	}
	@Test
	public void tCompareP2Smaller() {
		assertEquals(PAC.compare(pB, pA), 1);
	}
	@Test
	public void tCompareSameAsRef() {
		assertEquals(PAC.compare(ref1, pA), -1);
	}
	@Test
	public void tCompareSamePoint(){
		assertEquals(PAC.compare(pA, pA), 0);
	}
	
	@Test
	public void tCompareSamePolarP1Sm() {
		assertEquals(PAC.compare(pC, pD), -1); 
	}
	@Test
	public void tCompareSamePolarP2Sm() {
		assertEquals(PAC.compare(pD, pC), -1);
	}

}
