package edu.iastate.cs228.hw2;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertArrayEquals;
import java.util.Arrays;
import java.util.Arrays.*;
import java.util.Random;

import org.junit.Before;
import org.junit.Test;

public class SortersTest {
	int size = 1000;
	Point[] points = new Point[0];
	Point[] answer = new Point[size];
	AbstractSorter[] sorters = new AbstractSorter[4];

	@Before
	public void before() {
		Random r = new Random();
		points = generateRandomPoints(size, r);
		for (int i = 0; i < points.length; i++) {
			answer[i] = new Point(points[i]);
		}

		sorters[0] = new SelectionSorter(points);
		sorters[1] = new InsertionSorter(points);
		sorters[2] = new MergeSorter(points);
		sorters[3] = new QuickSorter(points);

	}

	@Test
	public void testSelect() {

		Arrays.sort(answer, new PolarAngleComparator(findLowest(answer)));
		sorters[0].sort(2);
		assertArrayEquals(sorters[0].points, answer);
		System.out.println(sorters[0].stats());

	}
//	
//	@Test
//	public void testInsert() {
//
//		Arrays.sort(answer, new PolarAngleComparator(findLowest(answer)));
//		sorters[1].sort(2);
//		assertArrayEquals(sorters[1].points, answer);
//		System.out.println(sorters[1].stats());
//
//	}
	
//	@Test
//	public void testMerge() {
//
//		Arrays.sort(answer, new PolarAngleComparator(findLowest(answer)));
//		sorters[2].sort(2);
//		printBoth(sorters[2].points, answer);
//		assertArrayEquals(sorters[2].points, answer);
//		

//	}
	
//	@Test
//	public void testQuick() {
//
//		Arrays.sort(answer, new PolarAngleComparator(findLowest(answer)));
//		sorters[3].sort(2);
//		assertArrayEquals(sorters[3].points, answer);
//		System.out.println(sorters[3].stats());
//
//	}
	
	public static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException {
		Point[] result = new Point[numPts];
		for (int i = 0; i < numPts; i++) {
			result[i] = new Point(rand.nextInt(101) - 50, rand.nextInt(101) - 50);
		}
		return result;
	}

	public Point findLowest(Point[] pts) {
		Point result = pts[0];
		for (int i = 1; i < pts.length; i++) {
			if (pts[i].getY() < result.getY()) {
				result = pts[i];
			} else if (pts[i].getY() == result.getY()) {
				if (pts[i].getX() < result.getX()) {
					result = pts[i];
				}
			}
		}
		return result;
	}
	
	public void printBoth(Point[] arr1, Point[] arr2) {
		for (int i = 0; i < arr1.length; i++) {
			System.out.println(arr1[i]+"\t"+arr2[i]);
		}
	}

}
