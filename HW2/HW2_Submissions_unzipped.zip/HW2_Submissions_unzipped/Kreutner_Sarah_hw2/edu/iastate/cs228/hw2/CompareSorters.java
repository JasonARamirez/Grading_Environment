package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner; 


public class CompareSorters 
{
	/**
	 * Repeatedly take integer sequences either randomly generated or read from files. 
	 * Perform the four sorting algorithms over each sequence of integers, comparing 
	 * points by x-coordinate or by polar angle with respect to the lowest point.  
	 * 
	 * @param args
	 * @throws InputMismatchException 
	 * @throws IOException 
	 **/
	public static void main(String[] args) throws InputMismatchException, IOException 
	{		
		// TODO 
		// 
		// Conducts multiple sorting rounds. In each round, performs the following: 
		// 
		//    a) If asked to sort random points, calls generateRandomPoints() to initialize an array 
		//       of random points. 
		//    b) Reassigns to elements in the array sorters[] (declared below) the references to the 
		//       four newly created objects of SelectionSort, InsertionSort, MergeSort and QuickSort. 
		//    c) Based on the input point order, carries out the four sorting algorithms in a for 
		//       loop that iterates over the array sorters[], to sort the randomly generated points
		//       or points from an input file.  
		//    d) Meanwhile, prints out the table of runtime statistics.
		// 
		// A sample scenario is given in Section 2 of the assignment description. 
		// 	
		AbstractSorter[] sorters = new AbstractSorter[4]; 
		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		Point [] points = new Point[0];
		int trialnum = 1;
		int key = 0;
		int numPoints;
		int order;
		String filename;
		
		System.out.println("Comparison of Four Sorting Algorithms\n");
		System.out.println("keys: 1 (random integers) 2 (file input) 3 (exit)\n");
		System.out.println("order: 1 (by x-coordinate) 2 (by polar angle)\n");
		
		while (key != 3) {
			System.out.println("Trial "+trialnum+" => Enter key: ");
			key = s.nextInt();
			trialnum++;
			
			if (key == 1 ) {
				System.out.println("Enter number of random points: ");
				numPoints = s.nextInt();
				Random r = new Random();
				points = generateRandomPoints(numPoints, r);
				sorters[0] = new SelectionSorter(points);
				sorters[1] = new InsertionSorter(points);
				sorters[2] = new MergeSorter(points);
				sorters[3] = new QuickSorter(points);
			}
			else if (key == 2) {
				System.out.println("Read from a file");
				System.out.println("Enter file name: ");
				filename = s.next();


				sorters[0] = new SelectionSorter(filename);
				sorters[1] = new InsertionSorter(filename);
				sorters[2] = new MergeSorter(filename);
				sorters[3] = new QuickSorter(filename);
			}
			
			else { break;}
			
			System.out.println("Order used in sorting: ");
			order = s.nextInt();
			String top = "\nalgorithm\t\tsize\t\ttime(ns)"
					+"\n-----------------------------------------------------";
			String bottom = "-----------------------------------------------------\n";
			
			System.out.println(top);
			for (AbstractSorter a: sorters) {
				a.sort(order);
				a.writePointsToFile();
				System.out.println(a.stats());
			}
			System.out.println(bottom);
		
		}
		// Within a sorting round, every sorter object write its output to the file 
		// "select.txt", "insert.txt", "merge.txt", or "quick.txt" if it is an object of 
		// SelectionSort, InsertionSort, MergeSort, or QuickSort, respectively. 
		
	}
	
	
	/**
	 * This method generates a given number of random points to initialize randomPoints[].
	 * The coordinates of these points are pseudo-random numbers within the range 
	 * [-50,50] � [-50,50]. Please refer to Section 3 of assignment description document on how such points can be generated.
	 * 
	 * Ought to be private. Made public for testing. 
	 * 
	 * @param numPts  	number of points
	 * @param rand      Random object to allow seeding of the random number generator
	 * @throws IllegalArgumentException if numPts < 1
	 */
	public static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException
	{ 	Point[] result = new Point[numPts];
		for (int i = 0; i<numPts; i++) {
			result[i] = new Point(rand.nextInt(101)-50, rand.nextInt(101)-50);
		}
		return result;
	}
}
