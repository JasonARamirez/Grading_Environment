package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException;
import java.lang.IllegalArgumentException;
import java.util.Comparator;
import java.util.InputMismatchException;
/**
 *  
 * @author brandon bui
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.
 *
 */

public class MergeSorter extends AbstractSorter {
	// Other private instance variables if you need ...

	/**
	 * The two constructors below invoke their corresponding superclass
	 * constructors. They also set the instance variables algorithm and
	 * outputFileName in the superclass.
	 */

	/**
	 * Constructor accepts an input array of points. in the array.
	 * 
	 * @param pts
	 *            input array of integers
	 */
	public MergeSorter(Point[] pts) {
		super(pts);
		this.algorithm = "merge sort";
		this.outputFileName = "mergesort.txt";
	}

	/**
	 * Constructor reads points from a file.
	 * 
	 * @param inputFileName
	 *            name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public MergeSorter(String inputFileName) throws InputMismatchException, FileNotFoundException {
		super(inputFileName);
		this.algorithm = "merge sort";
		this.outputFileName = "mergesort.txt";
	}

	/**
	 * Perform mergesort on the array points[] of the parent class
	 * AbstractSorter.
	 * 
	 * @param order
	 *            1 by x-coordinate 2 by polar angle
	 *
	 */
	@Override
	public void sort(int order) {
		if (order == 1){
			sortByAngle = false;
		}
		else if(order == 2){
			sortByAngle = true;
		}
		
		setComparator();
		long start = System.nanoTime();
		if (points == null || points.length == 0){
			throw new IllegalArgumentException();
		}
		Point[] tmp = new Point[points.length];
		mergeSortRec(points, tmp, 0, points.length-1, this.pointComparator);
		sortingTime = System.nanoTime() - start;
	}

	/**
	 * This is a recursive method that carries out mergesort on an array pts[]
	 * of points. One way is to make copies of the two halves of pts[],
	 * recursively call mergeSort on them, and merge the two sorted subarrays
	 * into pts[].
	 * 
	 * @param pts
	 *            point array
	 */
	
	private static void mergeSortRec(Point[] pts, Point[] tmp, int first, int last, Comparator<Point> comp) {

		if (first >= last)
			return;
		int i, j, k;
		int mid = (first + last) / 2;

		mergeSortRec(pts, tmp, first, mid, comp);
		mergeSortRec(pts, tmp, mid + 1, last, comp);
		k = first;
		for (i = first, j = mid + 1; i <= mid && j <= last;) {
			if (comp.compare(pts[i], pts[j]) == -1)
				tmp[k++] = pts[i++];
			else
				tmp[k++] = pts[j++];
		}

		while (i <= mid)
			tmp[k++] = pts[i++];
		while (j <= last)
			tmp[k++] = pts[j++];

		for (k = first; k <= last; k++)
			pts[k] = tmp[k];

	}

	// Other private methods in case you need ...

}
