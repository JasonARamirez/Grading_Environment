package edu.iastate.cs228.hw2;

/**
 *  
 * @author brandon bui

 *
 */

import java.util.Comparator;
import java.io.File;
import java.io.FileNotFoundException;
import java.lang.IllegalArgumentException;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.PrintWriter;
/**
 * 
 * This abstract class is extended by SelectionSort, InsertionSort, MergeSort,
 * and QuickSort. It stores the input (later on the sorted) sequence and records
 * the employed sorting algorithm, the comparison method, and the time spent on
 * sorting.
 *
 */

public abstract class AbstractSorter {

	protected Point[] points; // Array of points operated on by a sorting
								// algorithm.
								// The number of points is given by
								// points.length.

	protected String algorithm = null; // "selection sort", "insertion sort",
										// "merge sort", or "quick sort".
										// Initialized by a subclass
										// constructor.
	protected boolean sortByAngle; // true if last sort was done by polar angle
									// and false
									// if by x-coordinate

	protected String outputFileName; // "select.txt", "insert.txt", "merge.txt",
										// or "quick.txt"

	protected long sortingTime; // execution time in nanoseconds.

	protected Comparator<Point> pointComparator; // comparator which compares
													// polar angle if
													// sortByAngle == true and
													// x-coordinate if
													// sortByAngle == false

	private Point lowestPoint; // lowest point in the array, or in case of a
								// tie, the
								// leftmost of the lowest points. This point is
								// used
								// as the reference point for polar angle based
								// comparison.

	// Add other protected or private instance variables you may need.

	protected AbstractSorter() {
		// No implementation needed. Provides a default super constructor to
		// subclasses.
		// Removable after implementing SelectionSorter, InsertionSorter,
		// MergeSorter, and QuickSorter.
	}

	/**
	 * This constructor accepts an array of points as input. Copy the points
	 * into the array points[]. Sets the instance variable lowestPoint.
	 * 
	 * @param pts
	 *            input array of points
	 * @throws IllegalArgumentException
	 *             if pts == null or pts.length == 0.
	 */
	protected AbstractSorter(Point[] pts) throws IllegalArgumentException {
		//lowestPoint = null;
		
		if (pts == null || pts.length == 0) {
			throw new IllegalArgumentException("pts is null or the lenth is 0");
		} else {
			points = pts.clone();
		}
		lowestPoint = points[0];
		for(int i =0; i<points.length; i++ ){
			if(points[i].getX() < lowestPoint.getX()){
				lowestPoint = points[i];
			}
			else if(lowestPoint.getX() == points[i].getX()){
				if(points[i].getY() < lowestPoint.getY()){
					lowestPoint = points[i];
				}
			}
		}
	}

	/**
	 * This constructor reads points from a file. Sets the instance variables
	 * lowestPoint and outputFileName.
	 * 
	 * @param inputFileName
	 * @throws FileNotFoundException
	 * @throws InputMismatchException
	 *             when the input file contains an odd number of integers
	 */
	protected AbstractSorter(String inputFileName) throws FileNotFoundException, InputMismatchException {
		int counter = 0;
		int x = 0;
		int y = 0;
		
		File file = new File(inputFileName);
		Scanner in = new Scanner(file);
		if (file.exists() == false && file.isDirectory() == false) {
			throw new FileNotFoundException("File doesn't exist");
		}
		while (in.hasNextInt()) {
			in.nextInt();
			counter++;
		}
		in.close();
		if (counter % 2 != 0) {
			throw new InputMismatchException("file contains an odd number of ints");
		}
		Scanner in2 = new Scanner(file);
		
		int i = 0;
		points = new Point[counter/2];
		while(in2.hasNextInt()){
			
		
			 
				x = in2.nextInt();
				y = in2.nextInt();
				points[i] = new Point(x, y);
				i++;
	
		}
		
		in2.close();
		lowestPoint = points[0];
		for(i =0; i<points.length; i++ ){
			if(points[i].getX() < lowestPoint.getX()){
				lowestPoint = points[i];
			}
			else if(lowestPoint.getX() == points[i].getX()){
				if(points[i].getY() < lowestPoint.getY()){
					lowestPoint = points[i];
				}
			}
		}
		
	}

	/**
	 * Sorts the elements in points[].
	 * 
	 * a) in the non-decreasing order of x-coordinate if order == 1 b) in the
	 * non-decreasing order of polar angle w.r.t. lowestPoint if order == 2
	 * (lowestPoint will be at index 0 after sorting)
	 * 
	 * Sets the instance variable sortByAngle based on the value of order. Calls
	 * the method setComparator() to set the variable pointComparator and use it
	 * in sorting. Records the sorting time (in nanoseconds) using the
	 * System.nanoTime() method. (Assign the time to the variable sortingTime.)
	 * 
	 * @param order
	 *            1 by x-coordinate 2 by polar angle w.r.t lowestPoint
	 *
	 * @throws IllegalArgumentException
	 *             if order is less than 1 or greater than 2
	 */
	public abstract void sort(int order) throws IllegalArgumentException;

	/**
	 * Outputs performance statistics in the format:
	 * 
	 * <sorting algorithm> <size> <time>
	 * 
	 * For instance,
	 * 
	 * selection sort 1000 9200867
	 * 
	 * Use the spacing in the sample run in Section 2 of the assignment
	 * description.
	 */
	public String stats() {
		int i = 0;
		int num = 0;
		String statString = "";
		statString = statString + algorithm;
		num = 20 - statString.length();
		for (i = 0; i < num; i++) {
			statString = statString + " ";
		}
		statString = statString + points.length;
		num = 31 - statString.length();
		for (i = 0; i < num; i++) {
			statString = statString + " ";
		}
		statString = statString + sortingTime;

		return statString;

	}

	/**
	 * Write points[] to a string. When printed, the points will appear in order
	 * of increasing index with every point occupying a separate line. The x and
	 * y coordinates of the point are displayed on the same line with exactly
	 * one blank space in between.
	 */
	@Override
	public String toString() {
		String ptsString = "";
		for (int i = 0; i < points.length; i++) {
			ptsString = ptsString + points[i].getX() + " " + points[i].getY() + System.lineSeparator();

		}
		return ptsString;

	}

	/**
	 * 
	 * This method, called after sorting, writes point data into a file by
	 * outputFileName. It will be used for Mathematica plotting to verify the
	 * sorting result. The data format depends on sortByAngle. It is detailed in
	 * Section 4.1 of the assignment description assn2.pdf.
	 * 
	 * @throws FileNotFoundException
	 */
	public void writePointsToFile() throws FileNotFoundException {
		File f = new File(outputFileName);
		PrintWriter pw = new PrintWriter(f);
	
		if (sortByAngle == true){
			for(Point p : points){
				if(p.equals(lowestPoint)){
					pw.println(p.getX() + " " + p.getY());
				}
				else{
					pw.println(p.getX() + " " + p.getY() + " " +lowestPoint.getX() + " " + lowestPoint.getY() + " " + p.getX() + " " + p.getY());
				}
			}
		}
		else{
			for(Point p : points){
			pw.println(p.getX() + " " + p.getY());
			
		}
		}
		pw.close();
	}

	/**
	 * Generates a comparator on the fly that compares by polar angle if
	 * sortByAngle == true and by x-coordinate if sortByAngle == false. Set the
	 * protected variable pointComparator to it. Need to create an object of the
	 * PolarAngleComparator class and call the compareTo() method in the Point
	 * class, respectively for the two possible values of sortByAngle.
	 * 
	 * @param order
	 */
	protected void setComparator(){
		// Comparing by X-coordinates.
		
		/*if (order == 1){
			sortByAngle = false;
		}
		else if(order == 2){
			sortByAngle = true;
		}*/
		
		if (sortByAngle == false) {
			// Create a new comparator.
			pointComparator = new Comparator<Point>() {

				@Override
				public int compare(Point o1, Point o2) {

					return o1.compareTo(o2);
				}

			};
		} 
		else {
			// Compare by angle.
			pointComparator = new Comparator<Point>() {
				PolarAngleComparator aComparator = new PolarAngleComparator(lowestPoint);

				@Override
				public int compare(Point o1, Point o2) {
					return aComparator.compare(o1, o2);
				}
			};
		}
	}

	/*
	 * if(sortByAngle == true){
	 * 
	 * Comparator<Point> pointComparator = PolarAngleComparator(Point p); }
	 * if(sortByAngle == false){ pointComparator = new Comparator<Point>(){
	 * 
	 * @Override public int compare(Point o1, Point o2) { // TODO Auto-generated
	 * method stub return o1.compareTo(o2);
	 * 
	 * }
	 * 
	 * }
	 */

	/**
	 * Swap the two elements indexed at i and j respectively in the array
	 * points[].
	 * 
	 * @param i
	 * @param j
	 */
	protected void swap(int i, int j) {
		Point temp = points[i];
		points[i] = points[j];
		points[j] = temp;

	}
}
