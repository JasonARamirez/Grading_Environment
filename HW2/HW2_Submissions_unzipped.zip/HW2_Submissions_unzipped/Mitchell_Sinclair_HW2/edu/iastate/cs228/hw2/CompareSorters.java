package edu.iastate.cs228.hw2;

/**
 *  
 * @author Mitchell Sinclair
 *
 */

/**
 * 
 * This class executes four sorting algorithms: selection sort, insertion sort, mergesort, and
 * quicksort, over randomly generated integers as well integers from a file input. It compares the 
 * execution times of these algorithms on the same input. 
 *
 */

import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner; 
import java.util.Random; 


public class CompareSorters 
{
	static int Trial = 0;
	/**
	 * Repeatedly take integer sequences either randomly generated or read from files. 
	 * Perform the four sorting algorithms over each sequence of integers, comparing 
	 * points by x-coordinate or by polar angle with respect to the lowest point.  
	 * 
	 * @param args
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 **/
	public static void main(String[] args) throws InputMismatchException, FileNotFoundException 
	{		
		AbstractSorter[] sorters = new AbstractSorter[4]; 
		int numPoints;
		int order;
		int Key;
		String Input;
		Trial++;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Comparison of Four Sorting Algorithms");
		System.out.println("");
		System.out.println("keys: 1 (random integers) 2 (file input) 3 (exit)");
		System.out.println("order: 1 (by x-coordinate) 2 (by polar angle)");
		System.out.println("");
		System.out.print("Trial "+ Trial +" => Enter key: ");
	Key:
		while(true){
			Key = scan.nextInt();
			if(Key == 1){
				System.out.print("Enter number of random points: ");
				numPoints = scan.nextInt();
				Random Rand = new Random();
				Point[] points = generateRandomPoints(numPoints,Rand);
				sorters[0] = new SelectionSorter(points);
				sorters[1] = new InsertionSorter(points);
				sorters[2] = new MergeSorter(points);
				sorters[3] = new QuickSorter(points);
			}
			else if(Key == 2){
				System.out.print("Enter an input file name: ");
				Input = scan.next();
				sorters[0] = new SelectionSorter(Input);
				sorters[1] = new InsertionSorter(Input);
				sorters[2] = new MergeSorter(Input);
				sorters[3] = new QuickSorter(Input);
			}
			else if(Key == 3){
				return;
			}
			else{
				System.out.print("Input Key not valid, please enter a valid key: ");
				continue Key;
			}
			break;
		}
		System.out.print("Order used in sorting: ");
	Order:
		while(true){
			order = scan.nextInt();
			if(order == 1||order == 2){
				System.out.println("algorithm  size  time (ns)");
				System.out.println("---------------------------------------------\n");
				for(int i = 0; i < sorters.length; ++i){
					sorters[i].sort(order);
					System.out.println(sorters[i].stats());
				}
				System.out.println("\n---------------------------------------------\n\n");
				break;
			}
			else{
				System.out.print("Order entered is not valid, please enter a valid order: ");
				continue Order;
			}
		}
		// TODO 
		// 
		// Conducts multiple sorting rounds. In each round, performs the following: 
		// 
		//    a) If asked to sort random points, calls generateRandomPoints() to initialize an array 
		//       of random points. 
		//    b) Reassigns to elements in the array sorters[] (declared below) the references to the 
		//       four newly created objects of SelectionSort, InsertionSort, MergeSort and QuickSort. 
		//    c) Based on the input point order, carries out the four sorting algorithms in a for 
		//       loop that iterates over the array sorters[], to sort the randomly generated points
		//       or points from an input file.  
		//    d) Meanwhile, prints out the table of runtime statistics.
		// 
		// A sample scenario is given in Section 2 of the assignment description. 
		// 	
	
		
		// Within a sorting round, every sorter object write its output to the file 
		// "select.txt", "insert.txt", "merge.txt", or "quick.txt" if it is an object of 
		// SelectionSort, InsertionSort, MergeSort, or QuickSort, respectively. 
		main(args);
	}
	
	
	/**
	 * This method generates a given number of random points to initialize randomPoints[].
	 * The coordinates of these points are pseudo-random numbers within the range 
	 * [-50,50] ◊ [-50,50]. Please refer to Section 3 of assignment description document on how such points can be generated.
	 * 
	 * Ought to be private. Made public for testing. 
	 * 
	 * @param numPts  	number of points
	 * @param rand      Random object to allow seeding of the random number generator
	 * @throws IllegalArgumentException if numPts < 1
	 */
	public static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException
	{ 
		if(numPts < 1)
			throw new IllegalArgumentException();
		Point[] points = new Point[numPts];
		for(int i = 0; i < numPts; ++i){
			int point1 = rand.nextInt(51)*(rand.nextInt(2)-1);
			int point2 = rand.nextInt(51)*(rand.nextInt(2)-1);
			points[i] = new Point(point1,point2);
		}
		return points;
	}
	
}