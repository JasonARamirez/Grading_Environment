package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;

/**
 *  
 * @author Mitchell Sinclair
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	// Other private instance variables if you need ...
	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/** 
	 * Constructor accepts an input array of points. 
	 * in the array. 
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) throws IllegalArgumentException
	{
		super(pts); 
		algorithm = "MergeSorter";
		outputFileName = "merge.txt";
	}
	
	
	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 */
	public MergeSorter(String inputFileName) throws FileNotFoundException, InputMismatchException
	{
		super(inputFileName);
		algorithm = "MergeSorter";
		outputFileName = "merge.txt";
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{
		long time1 = System.nanoTime();
		if(order == 2)
			sortByAngle = true;
		else
			sortByAngle = false;
		mergeSortRec(points);
		long time2 = System.nanoTime();
		sortingTime = time2 - time1;
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts)
	{
		setComparator();
		if(pts.length == 1)
			return;
		
		int j, k;
	    int mid = (pts.length) / 2;
	    Point[] First = new Point[mid];
	    Point[] Last = new Point[pts.length - mid];
	    int count = 0;
	    for(int q = 0; q < pts.length; ++q){
	    	if(q < mid)
	    		First[q] = pts[q];
	    	else{
	    		Last[count] = pts[q];
	    		count++;
	    	}
	    }
	    
	    mergeSortRec(First);
	    mergeSortRec(Last);
	    
	    k = 0;
	    j = 0;
	    int h = 0;

	    	Point[] temp = new Point[pts.length];
	    	while(h < First.length && j < Last.length){
	  
	    		if(pointComparator.compare(First[h], Last[j]) == -1){
	    			temp[k] = First[h];
	    			k++;
	    			h++;
	    		}
	    		else if(pointComparator.compare(First[h], Last[j]) == 1){
	    			temp[k] = Last[j];
	    			k++;
	    			j++;
	    		}
	    	}
	    
	    	while(h < First.length){
	    		temp[k] = First[h];
	    		k++;
    			h++;
	    	}
	    	while(j < Last.length){
	    		temp[k] = Last[j];
	    		k++;
    			j++;
	    	}
	    
	    	for(int n = 0; n < pts.length; ++n)
	    		pts[n] = temp[n];
	    }
	
}