package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;

/**
 *  
 * @author Mitchell Sinclair
 *
 */

/**
 * 
 * This class implements the version of the quicksort algorithm presented in the lecture.   
 *
 */

public class QuickSorter extends AbstractSorter
{
	// Other private instance variables if you need ... 
		
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/** 
	 * Constructor accepts an input array of points. 
	 *   
	 * @param pts   input array of integers
	 */
	public QuickSorter(Point[] pts) throws IllegalArgumentException
	{
		super(pts);
		algorithm = "QuickSorter";
		outputFileName = "quick.txt";

	}
		

	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 */
	public QuickSorter(String inputFileName) throws FileNotFoundException,InputMismatchException
	{
		super(inputFileName);
		algorithm = "QuickSorter";
		outputFileName = "quick.txt";

	}


	/**
	 * Carry out quicksort on the array points[] of the AbstractSorter class.  
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{
		long time1 = System.nanoTime();
		if(order == 2)
			sortByAngle = true;
		else
			sortByAngle = false;
		setComparator();
		quickSortRec(0,points.length-1);
		long time2 = System.nanoTime();
		sortingTime = time2 - time1;
	}
	
	
	/**
	 * Operates on the subarray of points[] with indices between first and last. 
	 * 
	 * @param first  starting index of the subarray
	 * @param last   ending index of the subarray
	 */
	private void quickSortRec(int first, int last)
	{
		if(first >= last)
			return;
		
		int mid = partition(first,last);
		quickSortRec(first,mid);
		quickSortRec(mid+1,last);
	}
	
	
	/**
	 * Operates on the subarray of points[] with indices between first and last.
	 * 
	 * @param first
	 * @param last
	 * @return
	 */
	private int partition(int first, int last)
	{
		Point  pivot = points[first]; 
		  int  left = first;
		  int  right = last;
	
		  while(true){
			  while(pointComparator.compare(points[left], pivot) < 0)
				  left++;
			  while (pointComparator.compare(points[right], pivot) > 0)
				  right--;
			  if ( left < right ){
				 swap(left,right);
				 left++;
				 right--;
			  }
			  else
				  break;
		 }
		 return right;
	}	
		


	
	// Other private methods in case you need ...
}
