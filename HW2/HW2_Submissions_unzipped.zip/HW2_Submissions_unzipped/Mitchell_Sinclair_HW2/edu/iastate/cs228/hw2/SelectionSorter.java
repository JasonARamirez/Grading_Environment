package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;

/**
 *  
 * @author Mitchell Sinclair
 *
 */

/**
 * 
 * This class implements selection sort.   
 *
 */

public class SelectionSorter extends AbstractSorter
{
	// Other private instance variables if you need ... 
	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/**
	 * Constructor takes an array of points.
	 *  
	 * @param pts  
	 */
	public SelectionSorter(Point[] pts) throws IllegalArgumentException
	{
		super(pts);
		algorithm = "SelectionSorter";
		outputFileName = "select.txt";
	}	

	
	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 */
	public SelectionSorter(String inputFileName) throws FileNotFoundException, InputMismatchException
	{
		super(inputFileName);
		algorithm = "SelectionSorter";
		outputFileName = "select.txt";

	}
	
	
	/** 
	 * Apply selection sort on the array points[] of the parent class AbstractSorter.  
	 *
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{
		long time1 = System.nanoTime();
		if(order == 2)
			sortByAngle = true;
		else
			sortByAngle = false;
		setComparator();
			for(int i = 0; i < points.length; ++i){
				Point min = points[i];
				int loc = i;
				for(int n = i +1; n < points.length; ++n){
					if(pointComparator.compare(min, points[n]) == 1){
						min = points[n];
						loc = n;
					}
				}
				swap(loc,i);
		}
			long time2 = System.nanoTime();
			sortingTime = time2 - time1;
	}	
}
