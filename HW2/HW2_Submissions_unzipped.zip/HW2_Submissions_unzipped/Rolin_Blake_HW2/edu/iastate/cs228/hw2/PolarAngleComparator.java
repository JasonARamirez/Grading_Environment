package edu.iastate.cs228.hw2;

/**
 *  
 * @author
 *
 */

import java.util.Comparator;

/**
 * 
 * This class compares two points p1 and p2 by polar angle with respect to a reference point.  
 * It is known that the reference point is not above either p1 or p2, and in the case that
 * either or both of p1 and p2 have the same y-coordinate, not to their right. 
 *
 */
public class PolarAngleComparator implements Comparator<Point>
{
	private Point referencePoint; 
	
	/**
	 * 
	 * @param p reference point
	 */
	public PolarAngleComparator(Point p)
	{
		referencePoint = p; 
	}
	
	/**
	 * Use cross product and dot product to implement this method.  Do not take square roots 
	 * or use trigonometric functions. See the PowerPoint notes on how to carry out cross and 
	 * dot products. Calls private methods crossProduct() and dotProduct(). 
	 * 
	 * Call comparePolarAngle() and compareDistance(). 
	 * 
	 * @param p1
	 * @param p2
	 * @return  0 if p1 and p2 are the same point
	 *         negative otherwise, if one of the following three conditions holds:
	 *                a) p1 and referencePoint are the same point (hence p2 is a different point); 
	 *                b) neither p1 nor p2 equals referencePoint, and the polar angle of 	
	 *                   p1 with respect to referencePoint is less than that of p2; 
	 *                c) neither p1 nor p2 equals referencePoint, p1 and p2 have the same polar 
	 *                   angle w.r.t. referencePoint, and p1 is closer to referencePoint than p2. 
	 *   
	 *          positive  otherwise. 
	 *                   
	 */
	public int compare(Point p1, Point p2)
	{
		/* Method output description:
		 * returns 0 if: p1 & p2 are same(equidistant and same polar angle)
		 * 
		 * returns negative if: p1 = referencePoint
		 * 						p1PolarAngle < p2PolarAngle (w.r.t refPoint)
		 * 						p1PolarAngle = p2PolarAngle && p1Distance < p2Distance
		 * 
		 * returns positive if: p2 = referencePoint 
		 * 					    p2PolarAngle < p1PolarAngle (w.r.t refPoint)
		 * 					    p2PolarAngle = p1PolarAngle && p2Distance < p1Distance
		 * 
		 */
		
		if(comparePolarAngle(p1,p2) == 0){//if angles are same, compare by distance
			return compareDistance(p1,p2);//Dot-products
			/* if return = 0:Points are equidistant from refPoint/lowestPoint
			 * if return < 0(Negative):p1 is closer to referencePoint
			 * if return > 0(Positive):p2 is closer to referencePoint
			 */
		}//otherwise, compare by angle
			return comparePolarAngle(p1,p2);//Cross products
			/*if return = 0:Points have the same polar angle
			 *if return < 0(Negative):p1 = referecePoint OR p1Angle less than p2Angle
			 *if return > 0(Positive):p2Angle < p1Angle
			 */
	}
	
	
	/**
	 * Compare the polar angles of two points p1 and p2 with respect to referencePoint.  Use 
	 * cross products.  Do not use trigonometric functions. 
	 * 
	 * Ought to be private but made public for testing purpose. 
	 * 
	 * @param p1
	 * @param p2
	 * @return    0  if p1 and p2 have the same polar angle.(collinear)
	 * 			  negative  if p1 equals referencePoint or its polar angle with respect to referencePoint
	 *               is less than that of p2. 
	 *            positive  otherwise. 
	 */
    public int comparePolarAngle(Point p1, Point p2) 
    {
    	return Integer.compare(0, crossProduct(p1,p2));
    }
    
    
    /**
     * Compare the distances of two points p1 and p2 to referencePoint.  Use dot products. 
     * Do not take square roots. 
     * 
     * Ought to be private but made public for testing purpose.
     * 
     * @param p1
     * @param p2
     * @return    0   if p1 and p2 are equidistant to referencePoint
     * 			  negative   if p1 is closer to referencePoint 
     *            positive   otherwise (i.e., if p2 is closer to referencePoint)
     */
    public int compareDistance(Point p1, Point p2)
    {
    	 return dotProduct(p1,p1) - dotProduct(p2,p2);
    }
    

    /**
     * 
     * @param p1
     * @param p2
     * @return cross product of two vectors (p1 - referencePoint) and (p2 - referencePoint)
     */
    private int crossProduct(Point p1, Point p2)
    {	//p1 - rP & p2 - rP = (p1x - rPx, p1y - rPy) x (p2x - rPx, p2y - rPy)
    	int x1 = p1.getX() - referencePoint.getX();
    	int y1 = p1.getY() - referencePoint.getY();
    	int x2 = p2.getX() - referencePoint.getX();
    	int y2 = p2.getY() - referencePoint.getY();
    	
    	return (x1 * y2) - (x2 * y1); //x1y2 - x2y1
    	//p1 is lower if crossProduct > 0
    	//p1 is closer if crossProduct = 0 and magnitude of pRefP2 vector is greater than pRefp1 vector
    }

    /**
     * 
     * @param p1
     * @param p2
     * @return dot product of two vectors (p1 - referencePoint) and (p2 - referencePoint)
     */
    private int dotProduct(Point p1, Point p2)
    {	//p1 - rP & p2 - rP = (p1x - rPx, p1y - rPy) * (p2x - rPx, p2y - rPy)
    	int x1 = p1.getX() - referencePoint.getX();
    	int y1 = p1.getY() - referencePoint.getY();
    	int x2 = p2.getX() - referencePoint.getX();
    	int y2 = p2.getY() - referencePoint.getY();
    	
    	return (x1 * x2) + (y1 * y2); //x1x2 + y1y2
    }
}
