package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 

/**
 *  
 * @author
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	// Other private instance variables if you need ... 
	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/** 
	 * Constructor accepts an input array of points. 
	 * in the array. 
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		super(pts); 
		this.outputFileName = "merge.txt";
		this.algorithm = "merge sort";
	}
	
	
	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public MergeSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		super(inputFileName); 
		this.outputFileName = "merge.txt";
		this.algorithm = "merge sort";
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order) throws IllegalArgumentException
	{
		//Other possible exceptions/errors with array size are thrown by constructor, they are not included here
		
		this.startTime = System.nanoTime();//Set start time
		if(order < 1 || order > 2)
			throw new IllegalArgumentException("Invalid order number.");
		
		if(order == 1)
			this.sortByAngle = false;
		else
			this.sortByAngle = true;
		
		setComparator();//set comparator w/referencePoint = lowest point according to sortByAngle
		
		mergeSortRec(points, 0, points.length - 1);//perform sorting
		
		this.endTime = System.nanoTime();//set end time
		this.sortingTime = this.endTime - this.startTime;//set sorting time, calculated from end - start
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts, int left, int right)//the array, the left-most index and right-most index
	{
		if(left < right){//will skip if arrays are size 1; they are already sorted 
			//first define our middle index
			int mid = (left + (right - 1)) / 2;//avoids overflow/index errors by using right + 1
			//now use recursion for each half
			mergeSortRec(pts, left, mid);
			mergeSortRec(pts, mid + 1, right);
			//finally use private method to merge two halves
			merge(pts, left, mid, right);
		}
		
		
		/*int mid = (first + last) / 2;//find middle index
		
		Point[] half1 = Arrays.copyOfRange(points, 0, mid + 1);
		Point[] half2 = Arrays.copyOfRange(points, mid + 1, pts.length);
		
		mergeSortRec(half1, first, mid);//perform recursion on each half
		mergeSortRec(half2, mid + 1, last);
		
		Point[] temp = new Point[pts.length];//create new array to put sorted points in from each half/subarray
		//aka this is our working array
		
		//now we merge the sorted subarrays, starting from the begining of each half(pts[first] and pts[mid])
		int x, y;
		int z = 0;
		
		for(x = first, y = mid;  x <= mid && y < last;){//Define x & y, while x <= mid and y <= last(varying indexes)
			if(pointComparator.compare(half1[x], half2[y]) <= 0){//if compare returns negative(<=0), pts[x] is valued less
				temp[z] = half1[x];
				x++; z++;
			}else{//otherwise pts[y] is valued less(positive)
				temp[z] = half2[y];
				y++; z++;
			}
		}//end of merging for-loop
		
		 while (x <= mid) {//finish adding leftover indexes after all comparisons finish
		       temp[z] = half1[x];
		 	   z++; x++;
		 }
		 while (y < last) {
		       temp[z] = half2[y];
		 	   z++; y++;
		 }
		 
		 if (z != last + 1)//Check index in end to make sure no errors occurred
		     throw new RuntimeException("Error in index");

		 for (z = 0; z <= last; z++ )//put values of temp(sorted array) into the array we are using(this.points)
		     this.points[z] = temp[z];*/
		
		
		
		
	}

	
	// Other private methods in case you need ...
	private void merge(Point[] pts, int left, int mid, int right){
		int i,j,k;
		int sizeL = mid - left + 1;//size of left array
		int sizeR = right - mid;//size of right array
		//create new arrays for each side
		Point[] leftArr = new Point[sizeL];
		Point[] rightArr = new Point[sizeR];
		//populate both arrays
		for(i = 0; i < sizeL; i++){
			leftArr[i] = pts[left + i];//start from left-most index for left half
		}
		for(j = 0; j < sizeR; j++){
			rightArr[j] = pts[mid + 1 + j];//start from mid + 1 index for right half
		}
		//now that both half arrays are populated, merge them back into pts[], indexes left through right
		i = 0; j = 0; k = left;//set iterator variables to respective start points
		while(i < sizeL && j < sizeR){
			
			if(this.pointComparator.compare(leftArr[i],rightArr[j]) <= 0){//compare returns < 0, leftArr[i] is smaller, so it precedes
				pts[k] = leftArr[i];
				i++;
			}else{
				pts[k] = rightArr[j];//otherwise rightArr[j] is smaller, so it precedes 
				j++;
			}
			k++;//finally increment k
		}
		//Now, copy remaining elements from either array over.
		while(i < sizeL){
			pts[k] = leftArr[i];
			i++;
			k++;
		}
		while(j < sizeR){
			pts[k] = rightArr[j];
			j++;
			k++;
		}
	}//end of merge method
	
}

