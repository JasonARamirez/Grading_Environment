package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 


/**
 *  
 * @author
 *
 */

/**
 * 
 * This class implements the version of the quicksort algorithm presented in the lecture.   
 *
 */

public class QuickSorter extends AbstractSorter//QuickSorter up to spec
{
	
	// Other private instance variables if you need ... 
		
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/** 
	 * Constructor accepts an input array of points. 
	 *   
	 * @param pts   input array of integers
	 */
	public QuickSorter(Point[] pts)
	{
		super(pts);
		this.outputFileName = "quick.txt";
		this.algorithm = "quick sort";
	}
		

	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public QuickSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		super(inputFileName); 
		this.outputFileName = "quick.txt";
		this.algorithm = "quick sort";
	}


	/**
	 * Carry out quicksort on the array points[] of the AbstractSorter class.  
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{
		//Other possible exceptions/errors with array size are thrown by constructor, they are not included here
		
				this.startTime = System.nanoTime();//Set start time
				if(order < 1 || order > 2)
					throw new IllegalArgumentException("Invalid order number.");
				
				if(order == 1)
					this.sortByAngle = false;
				else
					this.sortByAngle = true;
				
				setComparator();//set comparator w/referencePoint = lowest point according to sortByAngle
				
				quickSortRec(0,points.length - 1);//perform sorting
				
				this.endTime = System.nanoTime();//set end time
				this.sortingTime = this.endTime - this.startTime;//set sorting time, calculated from end - start
	}
	
	
	/**
	 * Operates on the subarray of points[] with indices between first and last. 
	 * 
	 * @param first  starting index of the subarray
	 * @param last   ending index of the subarray
	 */
	private void quickSortRec(int first, int last)
	{
		if (last > first) {
		      int pivotIndex = partition(first, last);
		      quickSortRec(first, pivotIndex - 1);
		      quickSortRec(pivotIndex + 1, last);
		   }
	}
	
	
	/**
	 * Operates on the subarray of points[] with indices between first and last.
	 * 
	 * @param first
	 * @param last
	 * @return
	 */
	private int partition(int first, int last)
	{
		Point pivot = points[first]; // Choose the first element as the pivot
	    int low = first + 1; // Index for forward search
	    int high = last; // Index for backward search

	    while (high > low) {
	      // Search forward from left
	      while (low <= high && pointComparator.compare(points[low],pivot) <= 0)//while points[low] is less than/equal to pivot
	        low++;

	      // Search backward from right
	      while (low <= high && pointComparator.compare(points[high],pivot) > 0)//while points[high] is greater than pivot
	        high--;

	      // Swap two elements in the list
	      if (high > low) {//check indexes
	        swap(high,low);
	      }
	    }

	    while (high > first && pointComparator.compare(pivot,points[high]) <= 0)//while list[high] greater than or equal to pivot
	      high--;

	    // Swap pivot with list[high] if needed
	    if (pointComparator.compare(points[high],pivot) < 0) {//if points[high] is less than pivot
	      points[first] = points[high];
	      points[high] = pivot;
	      return high;
	    }
	    else {
	      return first;
	    }
	}	
		


	
	// Other private methods in case you need ...
}

