package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 


/**
 *  
 * @author Rolin Blake
 *
 */

/**
 * 
 * This class implements insertion sort.  
 */

public class InsertionSorter extends AbstractSorter //InsertionSorter up to spec 
{
	// Other private instance variables if you need ... 
	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/**
	 * Constructor takes an array of points. 
	 * 
	 * @param pts  
	 */
	public InsertionSorter(Point[] pts) 
	{
		super(pts);
		this.outputFileName = "insert.txt";
		this.algorithm = "insertion sort";
	}	

	
	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public InsertionSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		super(inputFileName);
		this.outputFileName = "insert.txt";
		this.algorithm = "insertion sort";
	}
	
	
	/** 
	 * Perform insertion sort on the array points[] of the parent class AbstractSorter.  
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 */
	@Override 
	public void sort(int order)
	{
		//Other possible exceptions/errors with array size are thrown by constructor, they are not included here
		
				this.startTime = System.nanoTime();//Set start time
				
				if(order < 1 || order > 2)
					throw new IllegalArgumentException("Invalid order number.");
				
				if(order == 1)
					this.sortByAngle = false;
				else
					this.sortByAngle = true;
				
				setComparator();//set comparator w/referencePoint = lowest point according to sortByAngle
				
				//perform sorting
				int i,j;
				Point curntPoint;
				//start by looking at 2nd element(sublist contains first element, we add elements to right of it)
				for(i = 1; i < points.length; i++){
					//set to current element to add to sublist
					curntPoint = points[i];//first element in the unsorted list(right of index 0)
					//
					for(j = i - 1; j >= 0 && pointComparator.compare(points[j], curntPoint) > 0; j--){
							//if points[j] is 'bigger' than curntPoint,
							points[j+1]= points[j];//move index i-1 to index i, move it to index of currentPoint
					}//end of nested for-loop
					
					points[j+1] = curntPoint;//put current point into index i
				}//end of initial for-loop
				//end of insertion sorting
				
				this.endTime = System.nanoTime();//set end time
				this.sortingTime = this.endTime - this.startTime;//set sorting time, calculated from end - start
	}		
}

