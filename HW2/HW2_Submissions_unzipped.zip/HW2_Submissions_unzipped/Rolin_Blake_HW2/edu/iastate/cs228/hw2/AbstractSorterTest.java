package edu.iastate.cs228.hw2;

import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.FileNotFoundException;
import java.util.InputMismatchException;

public class AbstractSorterTest {
	
	private static String filename = "points.txt";
	private static Point[] pts = {new Point(1,3), new Point(-1,-10), new Point(-1,2), new Point(2,6)};
	private static Point[] sortedPtsX = {new Point(-1,-10), new Point(-1,2), new Point(1,3), new Point(2,6)};
	private static Point[] sortedPtsA = {new Point(-1,-10), new Point(2,6), new Point(1,3), new Point(-1,2)};
	//array for the sorted version of the points read from file by x
	private static Point[] sortedFileX = {new Point(-10,0), new Point(-7,-10), new Point(-7,-10), new Point(-6,3),
			new Point(-3,-9), new Point(-2,1), new Point(-1,-6), new Point(0,-10), new Point(0,0), new Point(0,8),
			new Point(3,3), new Point(5,-2), new Point(5,5), new Point(7,3), new Point(8,4), new Point(10,5), new Point(10,5)};
	//array for the sorted version of the points read from file by y
	private static Point[] sortedFileA = {new Point(-7,-10), new Point(-7,-10), new Point(0,-10), new Point(-3,-9),
			new Point(-1,-6), new Point(5,-2), new Point(10,5), new Point(10,5), new Point(7,3), new Point(8,4),
			new Point(5,5), new Point(3,3), new Point(0,0), new Point(-2,1), new Point(0,8), new Point(-6,3), new Point(-10,0)};
	
	//our Point[] to call sort on, also will use filename to use points.txt
	private static AbstractSorter[] sortersArr = new AbstractSorter[4];
	private static AbstractSorter[] sortersFile = new AbstractSorter[4];
	//array to hold all sorters, defined in before all block
	
	@Before
	public void setSorters() throws InputMismatchException, FileNotFoundException{
		sortersArr[0] = new MergeSorter(pts);//index 0 is merge sorter
		sortersArr[1] = new QuickSorter(pts);//index 1 is quick sorter
		sortersArr[2] = new InsertionSorter(pts);//  2 is insrt sorter
		sortersArr[3] = new SelectionSorter(pts);//  3 is selec sorter
		
		sortersFile[0] = new MergeSorter(filename);//index 0 is merge sorter
		sortersFile[1] = new QuickSorter(filename);//index 1 is quick sorter
		sortersFile[2] = new InsertionSorter(filename);//  2 is insrt sorter
		sortersFile[3] = new SelectionSorter(filename);//  3 is selec sorter
	}
	
	@Test
	public void testFileConstructor() throws InputMismatchException, FileNotFoundException{
		assertEquals(sortersFile[0].points.length, 17);//there should be 17 points in points.txt
	}
	
	@Test
	public void testArrConstructor(){
		for(int i = 0; i < sortersArr.length; i++){
			for(int j = 0; j < pts.length; j++){
				assertEquals(sortersArr[i].points[j].compareTo(pts[j]), 0);//Each sorter's points[] should be the same as pts[j]
			}	//compareTo(Point) returns 0 if they are the same point
		}
	}
	
	
	@Test
	public void testSortingX(){
		//first, call sort on each sorter 
		for(int i = 0; i < sortersArr.length; i++){
			sortersArr[i].sort(1);
			assertFalse(sortersArr[i].sortByAngle);
		}
		for(int j = 0; j < sortersFile.length; j++){
			sortersFile[j].sort(1);
			assertFalse(sortersFile[j].sortByAngle);
		}
		//check indexes to see if they are equal
		for(int i = 0; i < sortersArr.length; i++){//for each sorter
			for(int j = 0; j < pts.length; j++){//for each point in their points[] field
				assertEquals(sortersArr[i].points[j].compareTo(sortedPtsX[j]), 0);//Each sorter's points[] should be the same as pts[j]
			}	//compareTo(Point) returns 0 if they are the same point
		}
		//repeat for sortersFile[]
		for(int i = 0; i < sortersFile.length; i++){//for each sorter
			for(int j = 0; j < pts.length; j++){//for each point in their points[] field
				assertEquals(sortersFile[i].points[j].compareTo(sortedFileX[j]), 0);//Each sorter's points[] should be the same as pts[j]
			}	//compareTo(Point) returns 0 if they are the same point
		}
	}
	
	@Test
	public void testSortingAngle(){//also checks the functionality of setting sortByAngle when calling sort()
		//first, call sort on each sorter 
			for(int i = 0; i < sortersArr.length; i++){
				sortersArr[i].sort(2);
				assertTrue(sortersArr[i].sortByAngle);
			}
			for(int j = 0; j < sortersFile.length; j++){
				sortersFile[j].sort(2);
				assertTrue(sortersFile[j].sortByAngle);
			}
			//check indexes to see if they are equal
			for(int i = 0; i < sortersArr.length; i++){//for each sorter
				for(int j = 0; j < pts.length; j++){//for each point in their points[] field
					assertEquals(sortersArr[i].points[j].compareTo(sortedPtsA[j]), 0);//Each sorter's points[] should be the same as pts[j]
				}	//compareTo(Point) returns 0 if they are the same point
			}
			//repeat for sortersFile[]
			for(int i = 0; i < sortersFile.length; i++){//for each sorter
				for(int j = 0; j < pts.length; j++){//for each point in their points[] field
					assertEquals(sortersFile[i].points[j].compareTo(sortedFileA[j]), 0);//Each sorter's points[] should be the same as pts[j]
				}	//compareTo(Point) returns 0 if they are the same point
			}
	}
	
	@Test
	public void testOutputFilenames(){
		String[] outputFn = {"merge.txt","quick.txt","insert.txt","select.txt"};
		for(int i = 0; i < sortersArr.length; i++){
			assertEquals(sortersArr[i].outputFileName, outputFn[i]);
			assertEquals(sortersFile[i].outputFileName, outputFn[i]);
		}
	}
	
	@Test
	public void testSwap(){
		Point[] somePoint = {new Point(10,10), new Point(11,11), new Point(12,12)};
		MergeSorter ms = new MergeSorter(somePoint);
		ms.swap(0,1);
		assertEquals(ms.points[1].toString(), somePoint[0].toString());
		assertEquals(ms.points[0].toString(), somePoint[1].toString());
	}
	
	@Test
	public void testExceptions(){
		Point[] p = new Point[0];
		try{
			AbstractSorter as = new MergeSorter(p);
		}catch(Exception e){
			assertEquals("Point array is null or undefined.",e.getMessage());
		}
		String s = "notafile.txt";
		try{
			AbstractSorter qs = new QuickSorter(s);
		}catch(Exception e){
			assertEquals("Odd number of integers in file.", e.getMessage());
		}
		try{
			Point[] p2 = null;
			AbstractSorter qs = new QuickSorter(p2);
			
		}catch(Exception e){
			assertEquals("Point array is null or undefined.",e.getMessage());
		}
		
	}
	
}
