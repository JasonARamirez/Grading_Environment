package edu.iastate.cs228.hw2;

/**
 *  
 * @author
 *
 */

import java.util.Comparator;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.IllegalArgumentException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * 
 * This abstract class is extended by SelectionSort, InsertionSort, MergeSort, and QuickSort.
 * It stores the input (later on the sorted) sequence and records the employed sorting algorithm, 
 * the comparison method, and the time spent on sorting. 
 *
 */


public abstract class AbstractSorter
{
	
	protected Point[] points;    // Array of points operated on by a sorting algorithm. 
	                             // The number of points is given by points.length.
	
	protected String algorithm = null; // "selection sort", "insertion sort",  
	                                   // "merge sort", or "quick sort". Initialized by a subclass 
									   // constructor.
	protected boolean sortByAngle;     // true if last sort was done by polar angle and false 
									   // if by x-coordinate 
	
	protected String outputFileName;   // "select.txt", "insert.txt", "merge.txt", or "quick.txt"
	
	protected long sortingTime; 	   // execution time in nanoseconds. 
	 
	protected Comparator<Point> pointComparator;  // comparator which compares polar angle if 
												  // sortByAngle == true and x-coordinate if 
												  // sortByAngle == false 
	
	private Point lowestPoint; 	    // lowest point in the array, or in case of a tie, the
									// leftmost of the lowest points. This point is used 
									// as the reference point for polar angle based comparison.
	
	protected File output;
	
	protected long startTime;
	protected long endTime;
	
	// Add other protected or private instance variables you may need. 
	
	protected AbstractSorter()
	{
		// No implementation needed. Provides a default super constructor to subclasses. 
		// Removable after implementing SelectionSorter, InsertionSorter, MergeSorter, and QuickSorter.
	}
	
	
	/**
	 * This constructor accepts an array of points as input. Copy the points into the array points[]. 
	 * Sets the instance variable lowestPoint.
	 * 
	 * @param  pts  input array of points 
	 * @throws IllegalArgumentException if pts == null or pts.length == 0.
	 */
	protected AbstractSorter(Point[] pts) throws IllegalArgumentException
	{
		if(pts == null || pts.length == 0){
			throw new IllegalArgumentException("Point array is null or undefined.");
		}
		
		this.points = new Point[pts.length];//Define points' size after checking for an IllegalArgumentException
		
		lowestPoint = pts[0];
		for(int i = 0; i < pts.length; i++){//Fill this.points with values from pts[]
			points[i] = pts[i];
		
			
			//If curnt lowestPoint is higher than pts[i] OR if they have same Y, but pts[i] is left of curnt lowestPoint
			if(lowestPoint.getY() > pts[i].getY() || (lowestPoint.getY() == pts[i].getY() && lowestPoint.getX() < pts[i].getX())){
				lowestPoint = pts[i];//set new lowest point.
			}//end of if
		}//end of for-loop
	}//end of constructor

	
	/**
	 * This constructor reads points from a file. Sets the instance variables lowestPoint and 
	 * outputFileName.
	 * 
	 * @param  inputFileName
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException   when the input file contains an odd number of integers
	 */
	@SuppressWarnings("resource")
	protected AbstractSorter(String inputFileName) throws FileNotFoundException, InputMismatchException
	{
		File input = new File(inputFileName);
		
		Scanner s = new Scanner(input);//will throw fnf exception if file doesn't exist
		
		int intCount = 0;
		while(s.hasNextInt()){//While scanner has a next int
			intCount++;//increment counter
			s.nextInt();//go to next int
		}
		if(intCount % 2 == 1) {//if # of ints is odd, throw im exception
			throw new InputMismatchException("Odd number of integers in file.");
		}
		s.close();
		
		this.points = new Point[intCount / 2];//finally define this.points array to be half of the number of counted ints, coordinate PAIRS
		
		Scanner s2 = new Scanner(input);//create new scanner to start from beginning of file again
		int i = 0;
		while(s2.hasNextInt() && i < points.length){//populate this.points from file now
			points[i] = new Point(s2.nextInt(), s2.nextInt());//Two ints in file represent (x,y)
			i++;
		}
		s2.close();
		
		lowestPoint = points[0];//Repeat lowest point operation
		for(int j = 0; j < points.length; j++){
			//If curnt lowestPoint is higher than points[j] OR if they have same Y, but points[j] is left of curnt lowestPoint
			if(lowestPoint.getY() > points[j].getY() || (lowestPoint.getY() == points[j].getY() && lowestPoint.getX() > points[j].getX())){
				lowestPoint = points[j];//set new lowest point.
			}//end of if
		}//end of for-loop
	}//end of constructor
	

	/**
	 * Sorts the elements in points[]. 
	 * 
	 *     a) in the non-decreasing order of x-coordinate if order == 1
	 *     b) in the non-decreasing order of polar angle w.r.t. lowestPoint if order == 2 
	 *        (lowestPoint will be at index 0 after sorting)
	 * 
	 * Sets the instance variable sortByAngle based on the value of order. Calls the method 
	 * setComparator() to set the variable pointComparator and use it in sorting.    
	 * Records the sorting time (in nanoseconds) using the System.nanoTime() method. 
	 * (Assign the time to the variable sortingTime.)  
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle w.r.t lowestPoint 
	 *
	 * @throws IllegalArgumentException if order is less than 1 or greater than 2
	 */
	public abstract void sort(int order) throws IllegalArgumentException; 
	
	
	/**
	 * Outputs performance statistics in the format: 
	 * 
	 * <sorting algorithm> <size>  <time>
	 * 
	 * For instance, 
	 * 
	 * selection sort   1000	  9200867
	 * 
	 * Use the spacing in the sample run in Section 2 of the assignment description. 
	 */
	public String stats()
	{
		String stats = String.format("%-15s %-10d %-10d \n", algorithm, points.length, sortingTime);
		//formatted string to return
		return stats;
	}
	
	
	/**
	 * Write points[] to a string.  When printed, the points will appear in order of increasing
	 * index with every point occupying a separate line.  The x and y coordinates of the point are 
	 * displayed on the same line with exactly one blank space in between. 
	 */
	@Override
	public String toString()
	{
		int x,y;
		String toReturn = "";//the string we are returning
		
		for(int i = 0; i < points.length; i++){//get all x/y coordinates and concatenate to a string
			x = points[i].getX();
			y = points[i].getY();
			toReturn += x + " " + y + "\n";//concatenate "x y" & newline
		}
		
		return toReturn;
	}

	
	/**
	 *  
	 * This method, called after sorting, writes point data into a file by outputFileName. It will 
	 * be used for Mathematica plotting to verify the sorting result.  The data format depends on 
	 * sortByAngle.  It is detailed in Section 4.1 of the assignment description assn2.pdf. 
	 * 
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public void writePointsToFile() throws FileNotFoundException, IOException
	{
		output = new File(outputFileName);//create file to write output to, where is file created
		
		PrintWriter printWriter = new PrintWriter(output);//create print writer to print to output file
		
		if(sortByAngle){//if we sorted by polar angle
			printWriter.println(points[0].getX() + " " + points[0].getX());//first line is just points[0]
			for(int i = 0; i < points.length; i++){
				printWriter.println(new String(points[i].getX() + " " + points[i].getY() + " " + points[0].getX() + " " + points[0].getY() + " " + points[i].getX() + " " + points[i].getY()));//other lines are points[i] + lowestPoint(points[0]) + points[i]
			}
		}else if(!sortByAngle){//else, if we sorted by x
			for(int i = 0; i < points.length; i++){
				printWriter.println(points[i].getX() + " " + points[i].getY());//prints in format of "(-)x y"
			}
		}
		printWriter.close();
	}	

	
	/**
	 * Generates a comparator on the fly that compares by polar angle if sortByAngle == true
	 * and by x-coordinate if sortByAngle == false. Set the protected variable pointComparator
	 * to it. Need to create an object of the PolarAngleComparator class and call the compareTo() 
	 * method in the Point class, respectively for the two possible values of sortByAngle.  
	 * 
	 * @param order
	 */
	protected void setComparator() 
	{
		if(this.sortByAngle){//if sortByAngle == true, compare by polar angle(unmodified PolarAngleComparator)
			this.pointComparator = new PolarAngleComparator(lowestPoint);//Set comparator to sort by polar angle
		}else{//if sortByAngle == false, compare by x
			this.pointComparator = new Comparator<Point>(){//anonymous inner class overrides compare method to use compareTo in Point class
				@Override
				public int compare(Point p1,Point p2){
					return p1.compareTo(p2);//returns 0 if they are same point, 
											//-1 if p2 has greater x or y coord(p1 is right of p1), 
											//1 otherwise(p2 is right of p1)
				}
			};
		}
	}

	
	/**
	 * Swap the two elements indexed at i and j respectively in the array points[]. 
	 * 
	 * @param i
	 * @param j
	 */
	protected void swap(int i, int j)
	{
		Point temp = points[i];//create temp for point[j]
		points[i] = points[j];//swap points[j]
		points[j] = temp;//use temp to swap points[i]
	}	
}

