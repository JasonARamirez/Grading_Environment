package edu.iastate.cs228.hw2;

import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.Comparator;

public class ComparatorTest {
	private static Point[] pts = {new Point(1,3), new Point(-1,-10), new Point(-1,2), new Point(2,6)};
								//(-1,-10),(2,6),(1,3),(-1,2) is sorted order by Angle
	private static Comparator<Point> comparator;
	private static Point refPoint = pts[1];//(-1,10) is our lowest point
	
	@Before
	public void setComparator(){
		comparator = new PolarAngleComparator(refPoint);
	}
	
	@Test
	public void testByAngle(){
		assertTrue(comparator.compare(pts[0], pts[1]) > 0);
		assertTrue(comparator.compare(pts[1], pts[2]) < 0);
		assertTrue(comparator.compare(pts[0], pts[0]) == 0);
		assertTrue(comparator.compare(pts[0], pts[3]) > 0);
	}

}
