package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 


/**
 *  
 * @author
 *
 */

/**
 * 
 * This class implements selection sort.   
 *
 */

public class SelectionSorter extends AbstractSorter//SelectionSort working up to spec
{
	// Other private instance variables if you need ... 
	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/**
	 * Constructor takes an array of points.
	 *  
	 * @param pts  
	 */
	public SelectionSorter(Point[] pts)  
	{
		super(pts); 
		this.outputFileName = "select.txt";
		this.algorithm = "selection sort";
	}	

	
	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public SelectionSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		super(inputFileName); 
		this.outputFileName = "select.txt";
		this.algorithm = "selection sort";
	}
	
	
	/** 
	 * Apply selection sort on the array points[] of the parent class AbstractSorter.  
	 *
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{
		//Other possible exceptions/errors with array size are thrown by constructor, they are not included here
		
				this.startTime = System.nanoTime();//Set start time
				if(order < 1 || order > 2)
					throw new IllegalArgumentException("Invalid order number.");
				
				if(order == 1)
					this.sortByAngle = false;
				else
					this.sortByAngle = true;
				
				setComparator();//set comparator w/referencePoint = lowest point according to sortByAngle
				
				//perform selection sort
				//from first index to second to last(list.length - 1), incrementing by 1
				Point currentMin;
				int currentMinIndex;
				for(int i = 0; i < points.length - 1; i++){
					currentMinIndex = i;
					currentMin = points[currentMinIndex];
					//find the minimum element in the list
					//first set current minimum to index i
					
					//from index to right of currentMin, to end of list(list.length), increment by 1
					for(int j = i + 1; j < points.length; j++){
						//get smallest index
						if(pointComparator.compare(points[j],currentMin) <= 0){//If element compared is less than currentMin
							currentMin = points[j];//set checked element to currentMin
							currentMinIndex = j;//set currentMinIndex to that of currentMin
						}
					}//end of nested for-loop
					
					//finally, swap points[i] with points[currentMinIndex] if necessary
					if(currentMinIndex != i){
						swap(i,currentMinIndex);
					}//end of if
					
				}//end of initial for-loop
				//end of selection sorting
				
				this.endTime = System.nanoTime();//set end time
				this.sortingTime = this.endTime - this.startTime;//set sorting time, calculated from end - start
	}	
}

