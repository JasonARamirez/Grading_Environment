 package edu.iastate.cs228.hw2;

/**
 * Class to represent a point on a cartesian-coordinate system, with (X,Y) values.
 * @author Rolin Blake
 */

public class Point implements Comparable<Point>
{
	private int x; 
	private int y;
	
	/**
	 * Default constructor w/ no parameters. X & Y are initialized
	 * to equal 0.
	 */
	public Point()
	{
		this.x = 0;
		this.y = 0;
	}
	
	/**
	 * Constructor that takes to integers as a parameter to represent (X,Y) values of the point.
	 * @param x This object's X-coordinate.
	 * @param y This object's Y-coordinate.
	 */
	public Point(int x, int y)
	{
		this.x = x;  
		this.y = y;   
	}
	
	/**
	 * Constructor with a Point-instance parameter to copy from.
	 * @param p The point to copy from.
	 */
	public Point(Point p) {
		x = p.getX();
		y = p.getY();
	}
	
	/**
	 * Returns the X-component of this point.
	 */
	public int getX()   
	{
		return x;
	}
	
	/**
	 * Returns the Y-component of this point.
	 */
	public int getY()
	{
		return y;
	}
	
	/**
	 * Returns true if the object compared is not null,
	 * is of the class Point, and the object's X,Y coordinates
	 * match this object's X,Y coordinates.
	 */
	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || obj.getClass() != this.getClass())
		{
			return false;
		}
    
		Point other = (Point) obj;
		return x == other.x && y == other.y;   
	}

	/**
	 * Compare this point with a second point q in the left-to-right order. 
	 * @param 	q 
	 * @return  -1  if this.x < q.x || (this.x == q.x && this.y < q.y) (This point is right of compared, or compared point has greater y)
	 * 		    0   if this.x == q.x && this.y == q.y (Same point)
	 * 			1	otherwise 
	 */
	public int compareTo(Point q)
	{
		if(this.x < q.x || (this.x == q.x && this.y < q.y)){//If q.x is greater than this.x, or if same x but q.y is greater than this.y
			return -1; //this object is 'less' than q
		}else if(this.x == q.x && this.y == q.y){//This points are the same, return 0
			return 0;
		}else{									//Otherwise return 1
			return 1;
		}
	}
	
	
	/**
	 * Outputs a point in the standard form (x, y) as a string. 
	 */
	@Override
    public String toString() 
	{
		return new String("(" + this.x + ", " + this.y + ")"); //Start parentheses, x, comma, space, y, end parentheses
	}
}

