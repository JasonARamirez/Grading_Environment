package edu.iastate.cs228.hw2;

import java.util.Arrays;

/**
 *  
 * @author	Shenmin Gong
 *
 */

import java.util.Comparator;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * 
 * This abstract class is extended by SelectionSort, InsertionSort, MergeSort, and QuickSort.
 * It stores the input (later on the sorted) sequence and records the employed sorting algorithm, 
 * the comparison method, and the time spent on sorting. 
 *
 */


public abstract class AbstractSorter
{
	
	protected Point[] points;    // Array of points operated on by a sorting algorithm. 
	                             // The number of points is given by points.length.
	
	protected String algorithm = null; // "selection sort", "insertion sort",  
	                                   // "merge sort", or "quick sort". Initialized by a subclass 
									   // constructor.
	protected boolean sortByAngle;     // true if last sort was done by polar angle and false 
									   // if by x-coordinate 
	
	protected String outputFileName;   // "select.txt", "insert.txt", "merge.txt", or "quick.txt"
	
	protected long sortingTime; 	   // execution time in nanoseconds. 
	 
	protected Comparator<Point> pointComparator;  // comparator which compares polar angle if 
												  // sortByAngle == true and x-coordinate if 
												  // sortByAngle == false 
	
	private Point lowestPoint; 	    // lowest point in the array, or in case of a tie, the
									// leftmost of the lowest points. This point is used 
									// as the reference point for polar angle based comparison.

	
	// Add other protected or private instance variables you may need. 
	
	protected AbstractSorter()
	{
		// No implementation needed. Provides a default super constructor to subclasses. 
		// Removable after implementing SelectionSorter, InsertionSorter, MergeSorter, and QuickSorter.
	}
	
	
	/**
	 * This constructor accepts an array of points as input. Copy the points into the array points[]. 
	 * Sets the instance variable lowestPoint.
	 * 
	 * @param  pts  input array of points 
	 * @throws IllegalArgumentException if pts == null or pts.length == 0.
	 */
	protected AbstractSorter(Point[] pts) throws IllegalArgumentException
	{
		if(pts == null || pts.length == 0) 
			throw new IllegalArgumentException();
		this.points = pts;	//copy the points into the array points[]
		lowestPoint = points[0];
		for (int i=0; i<pts.length; i++) {	//set the lowest point as the most left and low point
			if(lowestPoint.getY() > points[i].getY())
				lowestPoint = points[i];
			if(lowestPoint.getY() == points[i].getY())
				if(lowestPoint.getX() > points[i].getX())
					lowestPoint = points[i];
		}
	}

	
	/**
	 * This constructor reads points from a file. Sets the instance variables lowestPoint and 
	 * outputFileName.
	 * 
	 * @param  inputFileName
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException   when the input file contains an odd number of integers
	 */
	protected AbstractSorter(String inputFileName) throws FileNotFoundException, InputMismatchException
	{
		File f = new File(inputFileName);
		if(!f.exists())	
			throw new FileNotFoundException();
		Scanner s = new Scanner(f);
		int count=0;
		while(s.hasNextLine()) {
			Scanner line = new Scanner(s.nextLine());
			while(line.hasNextInt()) {
				int k = line.nextInt();
				count++;
			}
		}
		s.close();
		if(count % 2 != 0)	throw new InputMismatchException();
		Scanner a = new Scanner(f);
		int[] temp = new int[count];
		int k1 = 0, k2=0;
		while(a.hasNextLine()) {
			Scanner line = new Scanner(a.nextLine());
			while(line.hasNextInt()) {
				temp[k1] = line.nextInt();
				k1++;
			}
		}
		Point[] pts = new Point[count/2];
		for(int i=0; i<count/2;i++) {
			pts[i] = new Point(temp[k2],temp[k2 + 1]);
			k2 = k2 + 2; 
		}
		a.close();	
		lowestPoint = pts[0];
		for (int i=0; i<count/2; i++) {	//set the lowest point as the most left and low point
			if(lowestPoint.getY() > pts[i].getY())
				lowestPoint = pts[i];
			if(lowestPoint.getY() == pts[i].getY())
				if(lowestPoint.getX() > pts[i].getX())
					lowestPoint = pts[i];
		}
		this.points = pts;
	}
	

	/**
	 * Sorts the elements in points[]. 
	 * 
	 *     a) in the non-decreasing order of x-coordinate if order == 1
	 *     b) in the non-decreasing order of polar angle w.r.t. lowestPoint if order == 2 
	 *        (lowestPoint will be at index 0 after sorting)
	 * 
	 * Sets the instance variable sortByAngle based on the value of order. Calls the method 
	 * setComparator() to set the variable pointComparator and use it in sorting.    
	 * Records the sorting time (in nanoseconds) using the System.nanoTime() method. 
	 * (Assign the time to the variable sortingTime.)  
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle w.r.t lowestPoint 
	 *
	 * @throws IllegalArgumentException if order is less than 1 or greater than 2
	 */
	public abstract void sort(int order) throws IllegalArgumentException; 
	
	
	/**
	 * Outputs performance statistics in the format: 
	 * 
	 * <sorting algorithm> <size>  <time>
	 * 
	 * For instance, 
	 * 
	 * selection sort   1000	  9200867
	 * 
	 * Use the spacing in the sample run in Section 2 of the assignment description. 
	 */
	public String stats()
	{
		return algorithm + "      " + points.length + "         " +  sortingTime;  
	}
	
	
	/**
	 * Write points[] to a string.  When printed, the points will appear in order of increasing
	 * index with every point occupying a separate line.  The x and y coordinates of the point are 
	 * displayed on the same line with exactly one blank space in between. 
	 */
	@Override
	public String toString()
	{
		for(int i=0;i<points.length;i++)
			 System.out.println("(" + points[i].getX() + ", " + points[i].getY() + ")");
		return "";
		// TODO
	}

	
	/**
	 *  
	 * This method, called after sorting, writes point data into a file by outputFileName. It will 
	 * be used for Mathematica plotting to verify the sorting result.  The data format depends on 
	 * sortByAngle.  It is detailed in Section 4.1 of the assignment description assn2.pdf. 
	 * 
	 * @throws FileNotFoundException
	 */
	public void writePointsToFile() throws FileNotFoundException
	{
		File file = new File("/Users/shenmingong/eclipse-workspace/Coms228/src/edu/iastate/cs228/hw2/" + outputFileName);
		if(file.exists())
			throw new FileNotFoundException("file already exist");
		else {
			try {
				file.createNewFile();
			}catch(Exception e) {
				e.printStackTrace();
			}
			try {
				FileWriter file0 = new FileWriter(file);
				BufferedWriter writer = new BufferedWriter(file0);			
				if(sortByAngle==false) {	//sort by x-coordinate
					for(int i=0; i<points.length; i++)
						writer.write(points[i].toString() + "\n");
				}else {	//sort by polar angle
					writer.write(lowestPoint.toString() + "\n");
					for(int i=1; i<points.length; i++)
						writer.write(points[i].toString() + " " + lowestPoint.toString() + " " + points[i].toString() + "\n");
				}
				writer.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}	

	
	/**
	 * Generates a comparator on the fly that compares by polar angle if sortByAngle == true
	 * and by x-coordinate if sortByAngle == false. Set the protected variable pointComparator
	 * to it. Need to create an object of the PolarAngleComparator class and call the compareTo() 
	 * method in the Point class, respectively for the two possible values of sortByAngle.  
	 * 
	 * @param order
	 */
	protected void setComparator(int order) 
	{
		if(order == 1)	
			sortByAngle = false;
		if(order == 2)	
			sortByAngle = true;		
			this.pointComparator = new PolarAngleComparator(lowestPoint);
	}

	
	/**
	 * Swap the two elements indexed at i and j respectively in the array points[]. 
	 * 
	 * @param i
	 * @param j
	 */
	protected void swap(int i, int j)
	{
		Point temp = new Point();
		temp = points[i];
		points[i] = points[j];
		points[j] = temp;
	}	
}
