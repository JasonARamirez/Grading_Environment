package edu.iastate.cs228.hw2;

import java.io.File;

/**
 *  
 * @author	Shenmin Gong
 *
 */

/**
 * 
 * This class executes four sorting algorithms: selection sort, insertion sort, mergesort, and
 * quicksort, over randomly generated integers as well integers from a file input. It compares the 
 * execution times of these algorithms on the same input. 
 *
 */

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.Random; 


public class CompareSorters 
{
	/**
	 * Repeatedly take integer sequences either randomly generated or read from files. 
	 * Perform the four sorting algorithms over each sequence of integers, comparing 
	 * points by x-coordinate or by polar angle with respect to the lowest point.  
	 * 
	 * @param args
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 **/
	public static void main(String[] args) throws InputMismatchException, FileNotFoundException 
	{		
		// TODO 
		// 
		// Conducts multiple sorting rounds. In each round, performs the following: 
		// 
		//    a) If asked to sort random points, calls generateRandomPoints() to initialize an array 
		//       of random points. 
		//    b) Reassigns to elements in the array sorters[] (declared below) the references to the 
		//       four newly created objects of SelectionSort, InsertionSort, MergeSort and QuickSort. 
		//    c) Based on the input point order, carries out the four sorting algorithms in a for 
		//       loop that iterates over the array sorters[], to sort the randomly generated points
		//       or points from an input file.  
		//    d) Meanwhile, prints out the table of runtime statistics.
		// 
		// A sample scenario is given in Section 2 of the assignment description. 
		// 	
		AbstractSorter[] sorters = new AbstractSorter[4]; 
		Random rand = new Random();
		System.out.println("Comparison of Four Sorting Algorithms");
		System.out.println("");
		System.out.println("keys: 1 (random integers) 2 (file input) 3 (exit)");
		System.out.println("order: 1 (by x-coordinate) 2 (by polar angle)");
		System.out.println("");
		System.out.print("Enter key: ");
		Scanner scanner = new Scanner(System.in);
		int key = scanner.nextInt();
		if(key == 1) {
			System.out.print("Enter number of random points: ");
			int num = scanner.nextInt();
			System.out.print("Order used in sorting: ");
			int order = scanner.nextInt();
			System.out.println("");
			System.out.println("");
			System.out.println("");
			System.out.println("algorithm           size      time(ns)");
			System.out.println("_____________________________________\n");	
			sorters[0] = new SelectionSorter(generateRandomPoints(num, rand));
			sorters[1] = new InsertionSorter(generateRandomPoints(num,rand));
			sorters[2] = new MergeSorter(generateRandomPoints(num,rand));
			sorters[3] = new QuickSorter(generateRandomPoints(num,rand));
			sorters[0].sort(order);
			sorters[1].sort(order);
			sorters[2].sort(order);
			sorters[3].sort(order);
			System.out.println(sorters[0].stats());	
			System.out.println(sorters[1].stats());	
			System.out.println(sorters[2].stats());	
			System.out.println(sorters[3].stats());	
		}else if(key == 2) {
			System.out.println("Points from a file");
			System.out.printf("File name: ");
			String filename = scanner.next();
			System.out.println("Order used in sorting: ");
			int order = scanner.nextInt();
			System.out.println("");
			System.out.println("");
			System.out.println("");
			System.out.println("algorithm        size      time(ns)");
			System.out.println("___________________________________\n");
			sorters[0] = new SelectionSorter(filename);
			sorters[1] = new InsertionSorter(filename);
			sorters[2] = new MergeSorter(filename);
			sorters[3] = new QuickSorter(filename);
			sorters[0].sort(order);
			sorters[1].sort(order);
			sorters[2].sort(order);
			sorters[3].sort(order);
			System.out.println(sorters[0].stats());	
			System.out.println(sorters[1].stats());	
			System.out.println(sorters[2].stats());	
			System.out.println(sorters[3].stats());	
			sorters[0].writePointsToFile();;
			sorters[1].writePointsToFile();;
			sorters[2].writePointsToFile();;
			sorters[3].writePointsToFile();;
		}else {
			System.out.println("exit!");
		}		
		// Within a sorting round, every sorter object write its output to the file 
		// "select.txt", "insert.txt", "merge.txt", or "quick.txt" if it is an object of 
		// SelectionSort, InsertionSort, MergeSort, or QuickSort, respectively. 		
	}
	
	
	/**
	 * This method generates a given number of random points to initialize randomPoints[].
	 * The coordinates of these points are pseudo-random numbers within the range 
	 * [-50,50] � [-50,50]. Please refer to Section 3 of assignment description document on how such points can be generated.
	 * 
	 * Ought to be private. Made public for testing. 
	 * 
	 * @param numPts  	number of points
	 * @param rand      Random object to allow seeding of the random number generator
	 * @throws IllegalArgumentException if numPts < 1
	 */
	public static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException
	{ 
		if(numPts < 1)
			throw new IllegalArgumentException();
		Point[] temp = new Point[numPts];
		for(int i=0; i<numPts; i++)
			temp[i] = new Point(rand.nextInt(101)-50,rand.nextInt(101)-50);	
		return temp; 
	}
}
