package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 

/**
 *  
 * @author	Shenmin Gong
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/** 
	 * Constructor accepts an input array of points. 
	 * in the array. 
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		super(pts);
		algorithm = "merge sort    ";
		outputFileName = "merge.txt";
		// TODO  
	}
	
	
	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public MergeSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		super(inputFileName);
		algorithm = "merge sort    ";
		outputFileName = "merge.txt";
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{
		if(order==1)		 //x-coordinate
			sortByAngle = false;	
		if(order==2)		//polar angle
			sortByAngle = true;	
		if(order !=1 && order != 2)
			throw new IllegalArgumentException("wrong order");
		setComparator(order);
		sortingTime = System.nanoTime();
		mergeSortRec(points);
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts)
	{
		if( pts == null || pts.length == 0)
				throw new IllegalArgumentException("Null pointer or zero size");
		mergeSort(0,pts.length-1);
		//this.points = pts;
	}
	
	private void mergeSort(int low, int high) {
		//check if the low is smaller than high
		if(low < high) {
			//get the index of middle element
			int middle = low + (high - low) / 2;
			//sort the left side
			mergeSort(low, middle);
			//sort the right side
			mergeSort(middle+1, high);
			//merge both side
			merge(low,middle,high);		
		}
	}
	
	private void merge(int low, int mid, int high) {
		Point[] temp = new Point[points.length]; //working array
		 for (int i = low; i <= high; i++) 
	            temp[i] = points[i];
		 int i = low, j = mid + 1, k = low;
		 if(sortByAngle == false) {	//order 1 sort by x-coordinate 
			 while(i <= mid && j <= high) 
				 if(temp[i].compareTo(temp[j])== -1)
					 points[k++] = temp[i++];
				 else 
					 points[k++] = temp[j++];
			 while (i <= mid) 	//copy the rest subarray
		         points[k++] = temp[i++];		            
			 while(j < high)		//copy the rest subarray
				 points[k++] = temp[j++];
		 }else {		//order 2 sort by polar angle
			 while(i <= mid && j <= high) 
				 if(pointComparator.compare(temp[i], temp[j]) == -1) 
					 points[k++] = temp[i++];
				 else 
					 points[k++] = temp[j++];
			 while (i <= mid) 	//copy the rest subarray
		         points[k++] = temp[i++];		            
			 while(j < high)		//copy the rest subarray
				 points[k++] = temp[j++];
		 }		 
	}
}
