package edu.iastate.cs228.hw2;

/**
 *  
 * @author Luke Healy
 *
 */

/**
 * 
 * This class executes four sorting algorithms: selection sort, insertion sort, mergesort, and
 * quicksort, over randomly generated integers as well integers from a file input. It compares the 
 * execution times of these algorithms on the same input. 
 *
 */

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.Random;

public class CompareSorters {
	/**
	 * Repeatedly take integer sequences either randomly generated or read from
	 * files. Perform the four sorting algorithms over each sequence of integers,
	 * comparing points by x-coordinate or by polar angle with respect to the lowest
	 * point.
	 * 
	 * @param args
	 * @throws FileNotFoundException
	 * @throws InputMismatchException
	 **/
	public static void main(String[] args) throws InputMismatchException, FileNotFoundException { //
		//
		// Conducts multiple sorting rounds. In each round, performs the following:
		//
		// a) If asked to sort random points, calls generateRandomPoints() to initialize
		// an array
		// of random points.
		// b) Reassigns to elements in the array sorters[] (declared below) the
		// references to the
		// four newly created objects of SelectionSort, InsertionSort, MergeSort and
		// QuickSort.
		// c) Based on the input point order, carries out the four sorting algorithms in
		// a for
		// loop that iterates over the array sorters[], to sort the randomly generated
		// points
		// or points from an input file.
		// d) Meanwhile, prints out the table of runtime statistics.
		//
		// A sample scenario is given in Section 2 of the assignment description.
		//

		// Within a sorting round, every sorter object write its output to the file
		// "select.txt", "insert.txt", "merge.txt", or "quick.txt" if it is an object of
		// SelectionSort, InsertionSort, MergeSort, or QuickSort, respectively

		int trial = 1;
		while(true) {
		String newLine = System.lineSeparator();
		System.out.println("Comparison of Four Sorting Algorithms" + newLine);
		System.out.println("keys: 1 (random integers) 2 (file input) 3 (exit)");
		System.out.println("order: 1 (by x-coordinate) 2 (by polar angle)" + newLine);

		AbstractSorter[] sorters = new AbstractSorter[4];
		Random rand = new Random();

		System.out.println("Trial " + trial + " => Enter key: ");
		Scanner sc = new Scanner(System.in);
		int key = sc.nextInt();
		System.out.println("Enter number of random points: ");
		int numPoints = sc.nextInt();

		if (key == 1) {
			System.out.println("Order used in sorting: ");
			int order = sc.nextInt();
			System.out.println(newLine);
			System.out.println("algorithm\t" + "size\t" + "time(ns)\t");
			System.out.println("----------------------------------------------------");
			
			Point[] randoms = generateRandomPoints(numPoints, rand);
			sorters[0] = new SelectionSorter(randoms);
			sorters[1] = new InsertionSorter(randoms);
			sorters[2] = new MergeSorter(randoms);
			sorters[3] = new QuickSorter(randoms);
			for (int i = 0; i < sorters.length; i++) {
				sorters[i].sort(order);
				System.out.println(sorters[i].stats());
				sorters[i].writePointsToFile();
			}
			System.out.println("----------------------------------------------------");
			System.out.println(newLine);
		}
		if (key == 2) {
			System.out.println("Points from a file");
			System.out.println("File name: ");
			String filename = sc.next();
			System.out.println("Order used in sorting: ");
			int order = sc.nextInt();
			System.out.println("algorithm\t" + "size\t" + "time(ns)\t");
			System.out.println("----------------------------------------------------");
			sorters[0] = new SelectionSorter(filename);
			sorters[1] = new InsertionSorter(filename);
			sorters[2] = new MergeSorter(filename);
			sorters[3] = new QuickSorter(filename);
			for(int j = 0; j < sorters.length; j++) {
				sorters[j].sort(order);
				System.out.println(sorters[j].stats());
				sorters[j].writePointsToFile();
			}
			System.out.println("----------------------------------------------------");
			System.out.println(newLine);
		}
		trial++;
		if(key == 3)
			break;
	}
	}

	/**
	 * This method generates a given number of random points to initialize
	 * randomPoints[]. The coordinates of these points are pseudo-random numbers
	 * within the range [-50,50] � [-50,50]. Please refer to Section 3 of assignment
	 * description document on how such points can be generated.
	 * 
	 * Ought to be private. Made public for testing.
	 * 
	 * @param numPts
	 *            number of points
	 * @param rand
	 *            Random object to allow seeding of the random number generator
	 * @throws IllegalArgumentException
	 *             if numPts < 1
	 */
	public static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException {
		if (numPts < 1) {
			throw new IllegalArgumentException("Must have more points in array");
		}
		Point[] randomPointArr = new Point[numPts];
		for (int i = 0; i < numPts; i++) {
			randomPointArr[i] = new Point(rand.nextInt(101) - 50, rand.nextInt(101) - 5);
		}
		return randomPointArr;
	}
}
