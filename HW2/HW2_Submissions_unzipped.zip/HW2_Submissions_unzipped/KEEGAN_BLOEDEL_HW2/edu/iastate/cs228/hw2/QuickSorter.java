package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException; 


/**
 *  
 * @author Keegan Bloedel
 *
 */

/**
 * 
 * This class implements the version of the quicksort algorithm presented in the lecture.   
 *
 */

public class QuickSorter extends AbstractSorter
{
	
	// Other private instance variables if you need ... 
		
	/**
	 * The two constructors below invoke their corresponding superclass constructors. They
	 * also set the instance variables algorithm and outputFileName in the superclass.
	 */

	/** 
	 * Constructor accepts an input array of points. 
	 *   
	 * @param pts   input array of integers
	 */
	public QuickSorter(Point[] pts) throws IllegalArgumentException
	{
		super(pts);
		algorithm = "quick sort";
		outputFileName = "quick.txt"; 
	}
		

	/**
	 * Constructor reads points from a file. 
	 * 
	 * @param inputFileName  name of the input file
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException 
	 */
	public QuickSorter(String inputFileName) throws InputMismatchException, FileNotFoundException 
	{
		super(inputFileName);
		algorithm = "quick sort";
		outputFileName = "quick.txt"; 
	}


	/**
	 * Carry out quicksort on the array points[] of the AbstractSorter class.  
	 * 
	 * @param order  1   by x-coordinate 
	 * 			     2   by polar angle 
	 *
	 */
	@Override 
	public void sort(int order)
	{ 
		if(order == 1){
			sortByAngle = false;
		}
		else{
			sortByAngle = true;
		}
		setComparator();
		long start = System.nanoTime();
		this.quickSortRec(0, points.length);
		long end = System.nanoTime();
		sortingTime = end - start;
	}
	
	
	/**
	 * Operates on the subarray of points[] with indices between first and last. 
	 * 
	 * @param first  starting index of the subarray
	 * @param last   ending index of the subarray
	 */
	private void quickSortRec(int first, int last)
	{
		if (first >= last)
			return;
		int mid = this.partition(first, last);
		this.quickSortRec(first, mid);
		this.quickSortRec(mid+1, last);
	}
	
	
	/**
	 * Operates on the subarray of points[] with indices between first and last.
	 * 
	 * @param first
	 * @param last
	 * @return
	 */
	private int partition(int first, int last)
	{
		Point pivot = points[first];
		int left = first;
		int right = last;
		
		while (true){
			while(pointComparator.compare(points[left], pivot) < 0 )
				left++;
			while(pointComparator.compare(points[right], pivot) > 0)
				right--;
			if(left < right){
				Point p = points[left];
				points[left++] = points[right];
				points[right--] = p;
			}
			else 
				break;
			
		}
		
		return right; 
	}	
	
		


	
	// Other private methods in case you need ...
}
